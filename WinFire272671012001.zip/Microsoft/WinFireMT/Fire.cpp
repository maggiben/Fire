/*------------------------------------------------------------
WinFire
Eugene Ciloci
ciloci@sympatico.ca
August 31, 2001
  
Fire.cpp: Draws a very realistic fire effect

Original fire code by: Frank Jan Sorensen Alias:Frank Patxi (fjs@lab.jt.dk)
Translated from Pascal (BURN.PAS) into C++
------------------------------------------------------------*/

#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <memory.h>

#include <assert.h>

#include "Fire.h"

// :::::::::: CONSTANTS ::::::::::

// Fire control
const int ROOT_RAND		= 20;		// Max/Min decrease of the root of the flames 
const int DECAY			= 6;		// How far should the flames go up on the screen? 									
const int SMOOTH		= 2;		// How descrete can the flames be?
const int MIN_FIRE      = 50;		// limit between the "starting to burn" and
									// the "is burning" routines 
const int FIRE_INCREASE = 3;		// 3 = Wood, 90 = Gazolin

// Size and position
const int X_START       = 10;		// Startingpos on the screen 
const int X_END         = WIDTH-10;	// Guess! 
const int Y_START		= 0;		// Starting y position
const int FIRE_WIDTH	= X_END - X_START;	// Well- 
// 1 less because FIRE_HEIGHT is the limit of the y coordinate
// 1 more less because we draw fire pixels 1 above the limit
const int FIRE_HEIGHT	= HEIGHT - 2;

// Palette
const int MAX_COLOR     = 110;		// Constant for the MakePal procedure 
const int PALETTE_SIZE = 256;
const float PI = 3.14159f;

// :::::::::: ADT ::::::::::

// Structure to hold an RGB color triplet
struct RGB 
{
	BYTE r,g,b,dummy;	// add dummy to make structure an even 4 bytes
};

// :::::::::: FUNCTION PROTOTYPES ::::::::::

void CreatePalette(void);
RGB HSI2RGB (float H, float S, float I);
int RGB2PAL(RGB rgbColor);
RGB PAL2RGB(int index);
void SetPixel(BYTE * pBits, int x, int y, int color);
int GetPixel(BYTE * pBits, int x, int y);
int Random(int num);
void SetBuffer(BYTE * arg_pBits);

// :::::::::: GLOBALS ::::::::::

// Our palette
RGB arPalette[PALETTE_SIZE];
// The bottom of the fire
BYTE arSeed[FIRE_WIDTH];
// The buffer we draw to
BYTE * pBits;

#ifdef INPUT
// User's command
int iCommand;
#endif

// Burnability of fire
int iBurnability=3;

// :::::::::: FUNCTION DEFINITIONS ::::::::::

//------- CreatePalette ----------------------------------------------------------------------
/*
Purpose: Creates the palette
Description: Creates the various shades of color that we will use in the fire
Requirements: None
Returns: Nothing
*/
void CreatePalette(void)
{
	// Create first range of colors by using Hue, Saturation, and Intensity values
	for(int i=1;i<=MAX_COLOR;i++)
		arPalette[i] = HSI2RGB(4.6f-1.5f*((float)i/(float)MAX_COLOR),
								 (float)i/(float)MAX_COLOR,
								 1.1f*(float)i/(float)MAX_COLOR);

	// Create rest of range by manipulating individual RGB values
	for(i=MAX_COLOR;i<256;i++)
	{
		arPalette[i] = arPalette[i-1];

		if(arPalette[i].r < 63)
			arPalette[i].r++;
		if(arPalette[i].r < 63)
			arPalette[i].r++;

		if((i % 2 == 0) && (arPalette[i].g < 53))
			arPalette[i].g++;

		if((i % 2 == 0) && (arPalette[i].b < 63))
			arPalette[i].b++;
	}

	/* The original 256 color video mode that this fire program was written
	   for used 6 bits per RGB color to create the palette.  For this
	   reason the above code creates colors with maximum RGB values of 64 (2^6).
	   This creates a "faded" fire look.  So we must boost each value to its
	   maximum of 255.
	*/

	for(i=0;i<256;i++)
	{
		if((int)arPalette[i].r * 4 < 256)
			arPalette[i].r *= 4;
		else
			arPalette[i].r = 255;
		
		if((int)arPalette[i].g * 4 < 256)
			arPalette[i].g *= 4;
		else
			arPalette[i].g = 255;
		
		if((int)arPalette[i].b * 4 < 256)
			arPalette[i].b *= 4;
		else
			arPalette[i].b = 255;

		arPalette[i].dummy = 0;
	}
}

//------- HSI2RGB ----------------------------------------------------------------------
/*
Purpose: Converts a HSI value to an RGB value
Description: Converts a Hue, Saturation, Intensity value to a RGB value
Requirements: Three float value representing an HSI value
Returns: RGB color structure
*/
RGB HSI2RGB (float H, float S, float I)
{
	float R, G, B;
	RGB color;
	
	R = 1 + S * (float) sin(H - 2 * PI / 3);
	G = 1 + S * (float) sin(H);
	B = 1 + S * (float) sin(H + 2 * PI / 3);
	H = 63.999f * I / 2;
	
	color.r = (BYTE) (R * H);
	color.g = (BYTE) (G * H);
	color.b = (BYTE) (B * H);
	color.dummy = 0;

	return color;
}

//------- RGB2PAL ----------------------------------------------------------------------
/*
Purpose: Converts a RGB color value to an index into the palette
Description: Searches the palette until it finds a match and returns the index of that match
Requirements: RGB color
Returns: Index into palette
*/
int RGB2PAL(RGB rgbColor)
{
	int low, high;				// High and low limits of search
	int rgbAvg, rgAvg, Avg;		// Averages

	/* Normally, to find the color matching rgbColor, we just search the entire palette:
		for(int i=0;i<PALETTE_SIZE;i++)
		{
			RGB currentColor = arPalette[i];
			
			if((rgbColor.r == currentColor.r) &&
			   (rgbColor.g == currentColor.g) &&
			   (rgbColor.b == currentColor.b))
			   return i;		
		}
	Unfortunately, as a profiler will show, this will be the slowest part of the whole program!	
	*/

	/* To optimize this routine, you have to look at the palette and take advantage of some patterns.
	Using these optimizations, the framerate of the fire increased by 2.5x.*/
	
	// Colors from 226 to 255 all have the blue part equal to 252.
	if(rgbColor.b == 252)
	{
		return 226;
	}
	/* The index of colors from 144 to 225 (all of which have the green part equal to 212)
	can be very closely approximated by taking the average of the green and blue components. */
	else if(rgbColor.g == 212)
	{
		rgAvg = (rgbColor.g + rgbColor.b) >> 1;

		if(rgAvg - 6 < 144)
			low = 144;
		else
			low = rgAvg - 6;

		high = rgAvg;
	}
	/* The index of colors from 0 to 119 (all with green parts less than 164) can be very
	closely approximated by taking the average of all the parts and the average of the green
	and blue parts.  Then taking the average of those two values.*/	
	else if(rgbColor.g < 164)
	{	
		rgbAvg = (rgbColor.r + rgbColor.g + rgbColor.b) / 3;
		rgAvg = (rgbColor.g + rgbColor.b) >> 1;
		Avg = (rgbAvg + rgAvg) >> 1;

		if(Avg - 6 < 0)
			low = 0;
		else
			low = Avg - 6;

		if(Avg + 3 > 119)
			high = 119;
		else
			high = Avg + 3;		
	}
	/* For colors from 120 to 143 we just have to search the table. */
	else
	{
		low = 120;
		high = 143;
	}

	// Search the table
	for(int i=low;i < high+1;i++)
	{
		RGB currentColor = arPalette[i];
		
		if((rgbColor.r == currentColor.r) &&
		   (rgbColor.g == currentColor.g) &&
	       (rgbColor.b == currentColor.b))
			return i;		
	}	
			
	// No match?  Return something
	return 0;	
}

//------- PAL2RGB ----------------------------------------------------------------------
/*
Purpose: Converts an index into the palette into a RGB value
Description: Asserts that the index is within the palette's bounds.  Returns the RGB
			 color at index
Requirements: Index into palette
Returns: RGB color at that index
*/
RGB PAL2RGB(int index)
{
	// Check bounds
	assert((index >= 0) && (index < PALETTE_SIZE));

	return arPalette[index];
	
}	

//------- SetPixel ----------------------------------------------------------------------
/*
Purpose: Sets a pixel at x,y to a color
Description: Sets an RGB value at a specified x,y location in the buffer pBits
Requirements: pBits: pointer to buffer
			  x: x
			  y: y
			  color: index into palette
Returns: nothing
*/
void SetPixel(BYTE * pBits, int x, int y, int color)
{
	int offset;

	// Get offset into buffer
	offset = y * (WIDTH*BPP)+x*BPP;

	// Are we in the buffer?
	assert(offset < WIDTH*HEIGHT*BPP);
	
	pBits += offset;

	// Convert color into RGB
	RGB rgbColor = PAL2RGB(color);

	// Write
	*pBits++ = rgbColor.b;
	*pBits++ = rgbColor.g;
	*pBits = rgbColor.r;
}

//------- GetPixel ----------------------------------------------------------------------
/*
Purpose: Gets color of a pixel at x,y
Description: Gets an RGB value at a specified x,y location in the buffer pBits
Requirements: pBits: pointer to buffer
			  x: x
			  y: y			  
Returns: Index into palette of color at x,y
*/
int GetPixel(BYTE * pBits, int x, int y)
{
	RGB color;
	int offset;

	// Get offset into buffer
	offset = y * (WIDTH*BPP)+x*BPP;

	// Are we in the buffer?
	assert(offset < WIDTH*HEIGHT*BPP);
	
	pBits += offset;

	// Get RGB value
	color.b = *pBits++;
	color.g = *pBits++;
	color.r = *pBits;

	// Return index into palette of RGB color
	return RGB2PAL(color);
}

//------- Random ----------------------------------------------------------------------
/*
Purpose: Generate a random number
Description: Generates a random number between -num and num
Requirements: A number
Returns: Random number generated
*/
int Random(int num)
{
	return rand()%(num*2+1) - num;
}

//------- RandReal ----------------------------------------------------------------------
/*
Purpose: Generate a random floating point number
Description: Generates a random floating point number between 0.0 and 1.0
Requirements: Nothing
Returns: Generated random number
*/
float RandReal(void)
{
	return ((float)(rand()%1010) / (float)1000);
}

//------- InitFire ----------------------------------------------------------------------
/*
Purpose: Initalizes fire
Description: Seeds random number generator
			 Creates the palette
			 Sets address of buffer to write to
Requirements: Pointer to buffer
Returns: Nothing
*/
void InitFire(BYTE * pBits)
{
	srand(time(NULL));
	
	CreatePalette();

	SetBuffer(pBits);
}

#ifdef INPUT

//------- SetCommand ----------------------------------------------------------------------
/*
Purpose: Translates user's command into variables
Description: Sets iCommand to command issued and sets iBurnability to arg_iBurnability
Requirements: Command and burnability
Returns: Nothing
*/
void SetCommand(int arg_iCommand, int arg_iBurnability)
{
	iCommand = arg_iCommand;
	(arg_iBurnability == 0?iBurnability = 3: iBurnability = arg_iBurnability);
}

#endif

//------- SetBuffer ----------------------------------------------------------------------
/*
Purpose: Sets address of buffer
Description: Sets pBits to address of buffer
Requirements: BYTE Pointer to a buffer
Returns: Nothing
*/
void SetBuffer(BYTE * arg_pBits)
{
	pBits = arg_pBits;
}

//------- DrawFire ----------------------------------------------------------------------
/*
Purpose: Draws the fire
Description: Does a lot of magic with the color values of pixels and creates a fire effect!
Requirements: Nothing
Returns: Nothing
*/
void DrawFire()
{
	static int iMorefire = 3;

	// Put the values from FlameArray on the bottom line of the screen
	for(int x=0;x<FIRE_WIDTH;x++)
		SetPixel(pBits, x+X_START, Y_START, arSeed[x]);
		
	// This loop makes the actual flames
	for(x=X_START;x<=X_END;x++)
	{
		for(int y=FIRE_HEIGHT;y>=Y_START;y--)		// Makes fire "wild"
		//for(int y=Y_START;y<FIRE_HEIGHT;y++)		// Makes fire seem less "wild"
		{
			int color = GetPixel(pBits, x, y);

			// Note that we will draw one row above FIRE_HEIGHT
			if((color == 0) || (color < DECAY) || (x <= X_START) || (x >= X_END))
				SetPixel(pBits, x, y+1, 0);
			else
			{
				int newColor = color - rand()%DECAY;
			
				SetPixel(pBits, x - (rand()%3-1), y+1, newColor);
			}
		}
	}

	// Ignite!
	//if(rand()%150 == 0)
		memset(&arSeed[rand()%(FIRE_WIDTH-5)], 0xFF, 5);

#ifdef INPUT		
	// In-/Decrease?
	if(iCommand == COMMAND_DECREASE_INTENSITY)
	{
		if(iMorefire > -2)
			iMorefire--;
	}
	else if(iCommand == COMMAND_INCREASE_INTENSITY)
	{
		if(iMorefire < 4)
			iMorefire++;
	}
	else if(iCommand == COMMAND_INIT_FIRE)
	{
		memset((void *)arSeed, 0, FIRE_WIDTH);
	}
	else if(iCommand == COMMAND_WATER)
	{
		for(int i=0;i<10;i++)
			arSeed[rand()%FIRE_WIDTH] = 0;
	}

#endif
				
	// This loop controls the "root" of the
    // flames ie. the values in FlameArray.
	for(int i=0;i<FIRE_WIDTH;i++)
	{
		int color = arSeed[i];

		// Increase by the "burnability"
		if(color < MIN_FIRE)
		{
			// Starting to burn:
			if(color > 10)
				color += rand()%iBurnability;
		}
		// Otherwise randomize and increase by intensity (is burning)
		else
			color += rand()%ROOT_RAND + iMorefire;

		// color Too large ?
		if(color > 255)
			color = 255;

		arSeed[i] = color;
	}

	// Pour a little water on both sides of
    // the fire to make it look nice on the sides
	for(i=1; i<FIRE_WIDTH/8; i++)
	{
		float num = RandReal();
		int x = (int) ((float)(num * num) * (float)(FIRE_WIDTH / 8));

		// Set arSeed to x*10.  This lets the sides of the fire drop off so
		// it looks more realistic
		arSeed[x] = x*10;
		arSeed[FIRE_WIDTH - 1 - x] = x*10;
	}

	// Smoothen the values of FrameArray to avoid "discrete" flames
	for(i=SMOOTH;i< FIRE_WIDTH-SMOOTH;i++)
	{
		int x=0;

		for(int j=-SMOOTH;j<=SMOOTH;j++)
			x += arSeed[i+j];

		arSeed[i] = x / (2*SMOOTH+1);
	}

#ifdef INPUT
	// Reset 
	iCommand = 0;
#endif
}
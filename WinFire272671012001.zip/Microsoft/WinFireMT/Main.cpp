/*------------------------------------------------------------
WinFireMT
Eugene Ciloci
ciloci@sympatico.ca
August 31, 2001
  
Main.cpp: Provides the windows interface of the fire
------------------------------------------------------------*/

#include <windows.h>
#include <stdio.h>
#include <ctype.h>
#include <commctrl.h>
#include <tchar.h>
#include <process.h>
#include "resource.h"
#include "Fire.h"		// Include required constants

// Define SIZEABLE if you want to be able to resize the window and
// have the fire scale to the new size
#define SIZEABLE

#define IDC_STATUS_BAR	1		// Status bar ID
#define IDT_TIMER		1		// Timer ID

// :::::::::: ADT ::::::::::
struct THREAD_DATA
{
	BOOL bTerminate;			// TRUE if thread must stop
	HWND hWnd;					// Handle to window to draw to
	HDC hMemDC;					// Handle to our memory device context
	HBITMAP hBmp;				// Handle to our bitmap
	int iFrames;				// Number of frames we have drawn

	#ifdef SIZEABLE
	int iWidth, iHeight;		// Width and height of window
	#endif
};

// :::::::::: GLOBALS ::::::::::
CRITICAL_SECTION cs;			// Used to syncronize the thread with the main program

// :::::::::: FUNCTION PROTOTYPES ::::::::::

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK AboutDlgProc(HWND, UINT, WPARAM, LPARAM);
void DrawThread(void * pArg);
int Init(THREAD_DATA * pTD);
void Cleanup(THREAD_DATA * pTD);

// :::::::::: FUNCTION DEFINITIONS ::::::::::

/* Init
Purpose: To initialize everything required to draw the fire in our window
Description: Init creates a DIB section of width WIDTH, height HEIGHT
			 and 24bit color depth.  It then stores the address of the
			 DIB section's bits in pBits.  This is what we'll draw on.
			 By calling InitFire, we pass that address to the actual fire
			 drawing routine.  Finally we create a memory device context.
			 Stores the handle to the bitmap, handle to the memory DC in
			 the pTD argument
Requirements: Pointer to a THREAD_DATA structure
Returns:	0 - Success 
			-1 - Error
*/
int Init(THREAD_DATA * pTD)
{
	HDC hDC, hMemDC; 
	HBITMAP hBmp;
	BITMAPINFOHEADER bmih;
	BYTE * pBits;
	
	bmih.biSize = sizeof(BITMAPINFOHEADER);
	bmih.biWidth = WIDTH;
	bmih.biHeight = HEIGHT;
	bmih.biPlanes = 1;
	bmih.biBitCount = 24;
	bmih.biCompression = BI_RGB;
	bmih.biSizeImage = 0;
	bmih.biXPelsPerMeter = 0;
	bmih.biYPelsPerMeter = 0;
	bmih.biClrUsed = 0;
	bmih.biClrImportant = 0;

	// Allocate a region of memory for our fire and store its handle
	hBmp = CreateDIBSection(NULL, (BITMAPINFO *) &bmih, 0, (void **) &pBits, NULL, 0);

	if(hBmp == NULL)
		return -1;
	else
		// Save bitmap handle
		pTD->hBmp = hBmp;

	// Pass address of buffer to fire routine
	InitFire(pBits);

	hDC = GetDC(pTD->hWnd);

	if(hDC == NULL)
		return -1;

	// Get a memory DC
	hMemDC = CreateCompatibleDC(hDC);	
	SelectObject(hMemDC, hBmp);

	// Save memory DC
	pTD->hMemDC = hMemDC;
	
	ReleaseDC(pTD->hWnd, hDC);

	return 0;
}
        
//--------------------- DrawThread ------------------------------------------------
/*
Purpose: Draws the fire in our window
Description: Basically copies everything in the memory referenced by hMemDC to
			 the window
Requirements: Void pointer (which points to a THREAD_DATA struct)
Returns: Nothing
*/
void DrawThread(void * pArg)
{
	HDC hDC, hMemDC;				// Local copies of DCs
	HWND hWnd;						// Local copy of window handle
	volatile THREAD_DATA * pTD;		// Pointer to THREAD_DATA struct
									// Declared volatile because it can be modified outside
									// this thread
	BOOL bTerminate;				// Terminate?
	int iWidth, iHeight;			// Width and height of window

	pTD = (THREAD_DATA *)pArg;
	
	// Get handles
	hWnd = pTD->hWnd;
	hMemDC = pTD->hMemDC;	

	hDC = GetDC(hWnd);

	while(1)
	{
		EnterCriticalSection(&cs);
		bTerminate = pTD->bTerminate;
		iWidth = pTD->iWidth;
		iHeight = pTD->iHeight;
		LeaveCriticalSection(&cs);

		// Should we stop?
		if(bTerminate == TRUE)
			return;
	
		// Generate the fire and copy into our window
		DrawFire();
		
	#ifdef SIZEABLE
		// Stretch fire based on window size.  Slower and more pixelated
		StretchBlt(hDC, 0, 0, iWidth, iHeight, hMemDC, 0, 0, WIDTH, HEIGHT, SRCCOPY);	
	#else		
		// Copy everything from fire buffer to the window.  Fast but doesn't scale to window size
		BitBlt(hDC, 0, 0, WIDTH, HEIGHT, hMemDC, 0, 0, SRCCOPY);
	#endif

		// Increment frames drawn
		EnterCriticalSection(&cs);
		pTD->iFrames++;
		LeaveCriticalSection(&cs);	
	}

	ReleaseDC(hWnd, hDC);
}

//------- Cleanup ----------------------------------------------------------------------
/*
Purpose: To cleanup!
Description: Deletes the memory dc and releases the memory of our DIB section
Requirements: Pointer to a THREAD_DATA struct
Returns: Nothing
*/

void Cleanup(THREAD_DATA * pTD)
{
	// Release DC and bitmap memory
	DeleteDC(pTD->hMemDC);
	DeleteObject(pTD->hBmp);
}

// :::::::::: WinMain ::::::::::
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
     static TCHAR szAppName[] = TEXT ("WinFire") ;
     HWND         hWnd ;
     MSG          msg ;
     WNDCLASS     wndclass ;
	 DWORD iWindowStyle;
	 INITCOMMONCONTROLSEX  iccex;
	 int width, height;

     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (hInstance, szAppName) ;
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
     wndclass.lpszMenuName  = szAppName ;
     wndclass.lpszClassName = szAppName ;

     if (!RegisterClass (&wndclass))
     {
          MessageBox (NULL, TEXT ("This program requires Windows NT!"), 
                      szAppName, MB_ICONERROR) ;
          return 0 ;
     }

	 // Calculate height and width of our window
	 width = WIDTH + 2 * GetSystemMetrics(SM_CXEDGE);
	 height = HEIGHT + 2 * GetSystemMetrics(SM_CYEDGE) + 
		 GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYFIXEDFRAME)-1;

#ifdef SIZEABLE
	 iWindowStyle =  WS_OVERLAPPEDWINDOW;
#else
	iWindowStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
#endif
     
     hWnd = CreateWindow (szAppName,                  // window class name
                          TEXT ("Windows Fire!"), // window caption
							iWindowStyle,
                          CW_USEDEFAULT,              // initial x position
                          CW_USEDEFAULT,              // initial y position
						  width,					  // initial x size
                          height,					  // initial y size
                          NULL,                       // parent window handle
                          NULL,                       // window menu handle
                          hInstance,                  // program instance handle
                          NULL) ;                     // creation parameters

	 if(hWnd == NULL)
		 return -1;

	 // Load common controls library
	 iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	 iccex.dwICC = ICC_BAR_CLASSES;

	 InitCommonControlsEx(&iccex);	 
     
     ShowWindow (hWnd, iCmdShow) ;
     UpdateWindow (hWnd) ;	 

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg) ;
		DispatchMessage (&msg) ;
	}
	
	return msg.wParam ;	
}

// :::::::::: WndProc ::::::::::

LRESULT CALLBACK WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hWndStatusBar;		// Hold window handle of Status Bar
	static HINSTANCE hInstance;		// Hold our instance handle
	static int iSBHeight;			// Height of status bar
	static THREAD_DATA td;			// Data for thread
		
	// Create a status bar, resize the window to include it, and set a timer
	if(message == WM_CREATE)
	{		
		int iSBWidth;				// Width of status bar
		int iWinWidth, iWinHeight;	// Width and height of our window
		int iMenuHeight;			// Height of the menu bar
		int iWinNewHeight;			// New height of window
		int ySB;					// y position of status bar
		RECT rcSB, rcWin, rcWinClient;	// Rectangles of status bar, window, and client area
		
		hInstance = ((LPCREATESTRUCT) lParam)->hInstance;

		InitializeCriticalSection(&cs);
		
		// Fill in td structure
		td.bTerminate = FALSE;
		td.hWnd = hWnd;
		td.iFrames = 0;
		td.iHeight = HEIGHT;
		td.iWidth = WIDTH;
		
		// Problem intializing fire?
		if(Init(&td) != 0)
		{
			MessageBox(hWnd, TEXT("Could not initialize fire!"), TEXT("Error"), MB_OK | MB_ICONERROR);
			Cleanup(&td);
			return -1;
		}
		
LONG lSBStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | CCS_BOTTOM;

#ifdef SIZEABLE
		lSBStyle |= SBARS_SIZEGRIP;
#endif
		
		// Create status bar
		hWndStatusBar = CreateStatusWindow(lSBStyle,
										   TEXT("0 FPS"),
										   hWnd,
										   IDC_STATUS_BAR);
		// Get sizes of windows
		GetWindowRect(hWndStatusBar, &rcSB);
		GetClientRect(hWnd, &rcWinClient);
		GetWindowRect(hWnd, &rcWin);

		// Get height of menu bar
		iMenuHeight = GetSystemMetrics(SM_CYMENU);

		iSBWidth = rcSB.right - rcSB.left;
		iSBHeight = rcSB.bottom - rcSB.top;

		iWinWidth = rcWin.right - rcWin.left;
		iWinHeight = rcWin.bottom - rcWin.top;
		
		iWinNewHeight = iWinHeight + iSBHeight + iMenuHeight;

		ySB = rcWinClient.bottom + iMenuHeight;

		// Resize window and status bar
		MoveWindow(hWnd, rcWin.left, rcWin.top, iWinWidth, iWinNewHeight, TRUE);
		MoveWindow(hWndStatusBar, 0, ySB, iSBWidth, iSBHeight, TRUE);
	
		// Set a 500ms timer
		SetTimer(hWnd, IDT_TIMER, 500, NULL);
		
		// Start the fire
		_beginthread(DrawThread, 0, (void *) &td);

		return 0;
	}
	
#ifdef SIZEABLE			  
	else if(message == WM_SIZE)
	{		
		// Resize status bar
		SendMessage(hWndStatusBar, WM_SIZE, wParam, lParam);
		
		// Store new size of window
		EnterCriticalSection(&cs);
		td.iWidth = LOWORD(lParam);
		td.iHeight = HIWORD(lParam) - iSBHeight;
		LeaveCriticalSection(&cs);
		
		return 0;
	}
#endif	
	// Update FPS display
	else if(message == WM_TIMER)
	{		
		TCHAR szFPS[10];
			
		_sntprintf(szFPS, sizeof(szFPS)/sizeof(TCHAR), TEXT("%d FPS"), td.iFrames*2);

		// Update status bar
		SendMessage(hWndStatusBar, WM_SETTEXT, 0, (LPARAM) szFPS);

		EnterCriticalSection(&cs);
		td.iFrames = 0;
		LeaveCriticalSection(&cs);

		return 0;
	}
	// Menu stuff
	else if(message == WM_COMMAND)
	{		
		if(LOWORD(wParam) == IDM_HELP_ABOUT)
		{
			DialogBox(hInstance, TEXT("AboutBox"), hWnd, AboutDlgProc);	
		}

		return 0;
	}

#ifdef INPUT	
	// Translate key presses into fire controls
	else if(message == WM_CHAR)
	{
		int iCommand;
		int iBurnability = 0;
		  
		if((char)wParam == 'w')
			iCommand = COMMAND_WATER;
		else if((char)wParam == '+')
			iCommand = COMMAND_INCREASE_INTENSITY;
		else if ((char)wParam == '-')
			iCommand = COMMAND_DECREASE_INTENSITY;
		else if ((char)wParam == 'c')
			iCommand = COMMAND_INIT_FIRE;
		else if(isdigit((char)wParam))
		{
			iCommand = COMMAND_BURNABILITY;
			iBurnability = (char)wParam - '1';
			iBurnability *= iBurnability;
			iBurnability += 3;
		}

		SetCommand(iCommand, iBurnability);
		
		return 0;
	}
#endif
	
	else if(message == WM_DESTROY)
	{
		KillTimer(hWnd, IDT_TIMER);
		
		// Tell DrawThread to stop
		EnterCriticalSection(&cs);
		td.bTerminate = TRUE;
		LeaveCriticalSection(&cs);

		// Give it some time to stop before we delete the critical section
		Sleep(100);

		DeleteCriticalSection(&cs);

		Cleanup(&td);

		PostQuitMessage (0) ;
		return 0 ;
	}
	else
		return DefWindowProc (hWnd, message, wParam, lParam) ;
}

// Displays the about box dialog
BOOL CALLBACK AboutDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	if(message == WM_INITDIALOG)
	{
		return TRUE;
	}
	else if(message == WM_COMMAND)
	{
		if(LOWORD(wParam) == IDOK)
		{
			EndDialog(hDlg, 0);
			return TRUE;
		}
	}

	return FALSE;
}

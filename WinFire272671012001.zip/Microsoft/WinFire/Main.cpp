/*------------------------------------------------------------
WinFire
Eugene Ciloci
ciloci@sympatico.ca
August 31, 2001
  
Main.cpp: Provides the windows interface of the fire
------------------------------------------------------------*/

#include <windows.h>
#include <stdio.h>
#include <ctype.h>
#include <commctrl.h>
#include <tchar.h>
#include "resource.h"
#include "Fire.h"		// Include required constants

// Define SIZEABLE if you want to be able to resize the window and
// have the fire scale to the new size
#define SIZEABLE

#define IDC_STATUS_BAR	1		// Status bar ID
#define IDT_TIMER		1		// Timer ID

// :::::::::: GLOBALS ::::::::::
HDC g_hMemDC;				// Handle to our memory device context
HBITMAP g_hBmp;				// Handle to our bitmap
int g_iFrames;				// Number of frames we have drawn

#ifdef SIZEABLE
int g_iWidth, g_iHeight;	// Width and height of window
#endif

// :::::::::: FUNCTION PROTOTYPES ::::::::::

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK AboutDlgProc(HWND, UINT, WPARAM, LPARAM);
int Init(HWND arg_hWnd);
void Draw(HWND arg_hWnd);
void Cleanup(void);

// :::::::::: FUNCTION DEFINITIONS ::::::::::

/* Init
Purpose: To initialize everything required to draw the fire in our window
Description: Init creates a DIB section of width WIDTH, height HEIGHT
			 and 24bit color depth.  It then stores the address of the
			 DIB section's bits in pBits.  This is what we'll draw on.
			 By calling InitFire, we pass that address to the actual fire
			 drawing routine.  Finally we create a memory device context.
Requirements: Handle to a window
Returns:	0 - Success 
			-1 - Error
*/
int Init(HWND arg_hWnd)
{
	HDC hDC; 
	BITMAPINFOHEADER bmih;
	BYTE * pBits;
	
	bmih.biSize = sizeof(BITMAPINFOHEADER);
	bmih.biWidth = WIDTH;
	bmih.biHeight = HEIGHT;
	bmih.biPlanes = 1;
	bmih.biBitCount = 24;
	bmih.biCompression = BI_RGB;
	bmih.biSizeImage = 0;
	bmih.biXPelsPerMeter = 0;
	bmih.biYPelsPerMeter = 0;
	bmih.biClrUsed = 0;
	bmih.biClrImportant = 0;

	// Allocate a region of memory for our fire and store its handle
	g_hBmp = CreateDIBSection(NULL, (BITMAPINFO *) &bmih, 0, (void **) &pBits, NULL, 0);

	if(g_hBmp == NULL)
		return -1;	

	// Pass address of buffer to fire routine
	InitFire(pBits);

	hDC = GetDC(arg_hWnd);

	if(hDC == NULL)
		return -1;

	// Get a memory DC
	g_hMemDC = CreateCompatibleDC(hDC);
	SelectObject(g_hMemDC, g_hBmp);
	
	ReleaseDC(arg_hWnd, hDC);

	return 0;
}
        
//--------------------- Draw ------------------------------------------------
/*
Purpose: Draws fire in our window
Description: Basically copies everything in the memory referenced by hMemDC to
			 the window
Requirements: Handle to a window
Returns: Nothing
*/
void Draw(HWND arg_hWnd)
{
	HDC hDC;
	
	hDC = GetDC(arg_hWnd);

	// Generate the fire and copy into our window
	DrawFire();
	
#ifdef SIZEABLE
	// Stretch fire based on window size.  Slower and more pixelated
	StretchBlt(hDC, 0, 0, g_iWidth, g_iHeight, g_hMemDC, 0, 0, WIDTH, HEIGHT, SRCCOPY);	
#else		
	// Copy everything from fire buffer to the window.  Fast but doesn't scale to window size
	BitBlt(hDC, 0, 0, WIDTH, HEIGHT, g_hMemDC, 0, 0, SRCCOPY);
#endif

	g_iFrames++;

	ReleaseDC(arg_hWnd, hDC);	
}

//------- Cleanup ----------------------------------------------------------------------
/*
Purpose: To cleanup!
Description: Deletes the memory dc and releases the memory of our DIB section
Requirements: None
Returns: Nothing
*/

void Cleanup(void)
{
	DeleteDC(g_hMemDC);
	DeleteObject(g_hBmp);
}

// :::::::::: WinMain ::::::::::
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
     static TCHAR szAppName[] = TEXT ("WinFire") ;
     HWND         hWnd ;
     MSG          msg ;
     WNDCLASS     wndclass ;
	 DWORD iWindowStyle;
	 INITCOMMONCONTROLSEX  iccex;
	 int width, height;

     wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
     wndclass.lpfnWndProc   = WndProc ;
     wndclass.cbClsExtra    = 0 ;
     wndclass.cbWndExtra    = 0 ;
     wndclass.hInstance     = hInstance ;
     wndclass.hIcon         = LoadIcon (hInstance, szAppName) ;
     wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
     wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
     wndclass.lpszMenuName  = szAppName ;
     wndclass.lpszClassName = szAppName ;

     if (!RegisterClass (&wndclass))
     {
          MessageBox (NULL, TEXT ("This program requires Windows NT!"), 
                      szAppName, MB_ICONERROR) ;
          return 0 ;
     }

	 
	 // Calculate height and width of our window
	 width = WIDTH + 2 * GetSystemMetrics(SM_CXEDGE);
	 height = HEIGHT + 2 * GetSystemMetrics(SM_CYEDGE) + 
		 GetSystemMetrics(SM_CYCAPTION) + GetSystemMetrics(SM_CYFIXEDFRAME)-1;

#ifdef SIZEABLE
	 iWindowStyle =  WS_OVERLAPPEDWINDOW;
#else
	iWindowStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
#endif
     
     hWnd = CreateWindow (szAppName,                  // window class name
                          TEXT ("Windows Fire!"), // window caption
							iWindowStyle,
                          CW_USEDEFAULT,              // initial x position
                          CW_USEDEFAULT,              // initial y position
						  width,					  // initial x size
                          height,					  // initial y size
                          NULL,                       // parent window handle
                          NULL,                       // window menu handle
                          hInstance,                  // program instance handle
                          NULL) ;                     // creation parameters

	 // Load common controls library
	 iccex.dwSize = sizeof(INITCOMMONCONTROLSEX);
	 iccex.dwICC = ICC_BAR_CLASSES;

	 InitCommonControlsEx(&iccex);	 
     
     ShowWindow (hWnd, iCmdShow) ;
     UpdateWindow (hWnd) ;

	 // Problem intializing fire?
	 if(Init(hWnd) != 0)
	 {
		MessageBox(NULL, TEXT("Could not initialize fire!"), TEXT("Error"), MB_OK | MB_ICONERROR);
		Cleanup();
		return -1;
	 }

	 // Draw fire when there are no other messages to process
	 while(1)
	 {
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			if(msg.message == WM_QUIT)
				break;

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		;
			// Draw fire
			Draw(hWnd);
	 }

	 Cleanup();

     return msg.wParam ;
}

// :::::::::: WndProc ::::::::::

LRESULT CALLBACK WndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND hWndStatusBar;		// Hold window handle of Status Bar
	static HINSTANCE hInstance;		// Hold our instance handle
	static int iSBHeight;			// Height of status bar
	
	// Create a status bar, resize the window to include it, and set a timer
	if(message == WM_CREATE)
	{		
		int iSBWidth;				// Width of status bar
		int iWinWidth, iWinHeight;	// Width and height of our window
		int iMenuHeight;			// Height of the menu bar
		int iWinNewHeight;			// New height of window
		int ySB;					// y position of status bar
		RECT rcSB, rcWin, rcWinClient;	// Rectangles of status bar, window, and client area
		
		hInstance = ((LPCREATESTRUCT) lParam)->hInstance;
		
		LONG lSBStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | CCS_BOTTOM;

#ifdef SIZEABLE
		lSBStyle |= SBARS_SIZEGRIP;
#endif
		
		// Create status bar
		hWndStatusBar = CreateStatusWindow(lSBStyle,
										   TEXT("0 FPS"),
										   hWnd,
										   IDC_STATUS_BAR);

		// Get sizes of windows
		GetWindowRect(hWndStatusBar, &rcSB);
		GetClientRect(hWnd, &rcWinClient);
		GetWindowRect(hWnd, &rcWin);

		// Get height of menu bar
		iMenuHeight = GetSystemMetrics(SM_CYMENU);

		iSBWidth = rcSB.right - rcSB.left;
		iSBHeight = rcSB.bottom - rcSB.top;

		iWinWidth = rcWin.right - rcWin.left;
		iWinHeight = rcWin.bottom - rcWin.top;
		
		iWinNewHeight = iWinHeight + iSBHeight + iMenuHeight;

		ySB = rcWinClient.bottom + iMenuHeight;

		// Resize window and status bar
		MoveWindow(hWnd, rcWin.left, rcWin.top, iWinWidth, iWinNewHeight, TRUE);
		MoveWindow(hWndStatusBar, 0, ySB, iSBWidth, iSBHeight, TRUE);
	
		// Set a 500ms timer
		SetTimer(hWnd, IDT_TIMER, 500, NULL);

		return 0;
	}
#ifdef SIZEABLE			  
	else if(message == WM_SIZE)
	{
		// Store new size of window
		g_iWidth = LOWORD(lParam);
		g_iHeight = HIWORD(lParam) - iSBHeight;

		// Resize status bar
		SendMessage(hWndStatusBar, WM_SIZE, wParam, lParam);

		return 0;
	}
#endif
	// Update FPS display
	else if(message == WM_TIMER)
	{		
		TCHAR szFPS[10];
		
		_sntprintf(szFPS, sizeof(szFPS)/sizeof(TCHAR), TEXT("%d FPS"), g_iFrames*2);

		// Update status bar
		SendMessage(hWndStatusBar, WM_SETTEXT, 0, (LPARAM) szFPS);

		g_iFrames = 0;

		return 0;
	}
	// Menu stuff
	else if(message == WM_COMMAND)
	{		
		if(LOWORD(wParam) == IDM_HELP_ABOUT)
		{
			DialogBox(hInstance, TEXT("AboutBox"), hWnd, AboutDlgProc);	
		}

		return 0;
	}

#ifdef INPUT	
	// Translate key presses into fire controls
	else if(message == WM_CHAR)
	{
		int iCommand;
		int iBurnability = 0;
		  
		if((char)wParam == 'w')
			iCommand = COMMAND_WATER;
		else if((char)wParam == '+')
			iCommand = COMMAND_INCREASE_INTENSITY;
		else if ((char)wParam == '-')
			iCommand = COMMAND_DECREASE_INTENSITY;
		else if ((char)wParam == 'c')
			iCommand = COMMAND_INIT_FIRE;
		else if(isdigit((char)wParam))
		{
			iCommand = COMMAND_BURNABILITY;
			iBurnability = (char)wParam - '1';
			iBurnability *= iBurnability;
			iBurnability += 3;
		}

		SetCommand(iCommand, iBurnability);
		
		return 0;
	}
#endif
	
	else if(message == WM_DESTROY)
	{
		KillTimer(hWnd, IDT_TIMER);		

		PostQuitMessage (0) ;
		return 0 ;
	}
	else
		return DefWindowProc (hWnd, message, wParam, lParam) ;
}

// Displays the about box dialog
BOOL CALLBACK AboutDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	if(message == WM_INITDIALOG)
	{
		return TRUE;
	}
	else if(message == WM_COMMAND)
	{
		if(LOWORD(wParam) == IDOK)
		{
			EndDialog(hDlg, 0);
			return TRUE;
		}
	}

	return FALSE;
}

/*------------------------------------------------------------
WinFire
Eugene Ciloci
ciloci@sympatico.ca
August 31, 2001
  
Fire.h: Defines the required constants for the fire
------------------------------------------------------------*/

#ifndef FIRE_H
#define FIRE_H

/* Define INPUT if you want keyboard input so as to be able to
control the fire.  I found that the input options did not apreciably 
affect the fire (except for water).
*/
//#define INPUT

#ifdef INPUT

#define COMMAND_WATER 1
#define COMMAND_INCREASE_INTENSITY 2
#define COMMAND_DECREASE_INTENSITY 3
#define COMMAND_INIT_FIRE 4
#define COMMAND_BURNABILITY 5

#endif

// shorthand
typedef unsigned char BYTE;

// Bits per pixel.  Used by the Set/GetPixel routines.
// The DIB section is created as 24bpp.
const int BPP = 3;

// Width and height of the buffer (or window)
const int WIDTH = 200;
const int HEIGHT = 100;

// Initalizes the fire
void InitFire(BYTE * pBits);
// Draws the fire
void DrawFire();


#ifdef INPUT

// Sets various variables of fire according to key pressed
void SetCommand(int arg_iCommand, int arg_iBurnability);

#endif

#endif
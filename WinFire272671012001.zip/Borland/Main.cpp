/*------------------------------------------------------------
WinFire
Eugene Ciloci
ciloci@sympatico.ca
October 1, 2001

Main.cpp: Provides the windows interface of the fire
------------------------------------------------------------*/

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "Main.h"
#include "Fire.h"
#include "About.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
    BITMAPINFOHEADER bmih;
	BYTE * pBits;

	bmih.biSize = sizeof(BITMAPINFOHEADER);
	bmih.biWidth = WIDTH;
	bmih.biHeight = HEIGHT;
	bmih.biPlanes = 1;
	bmih.biBitCount = 24;
	bmih.biCompression = BI_RGB;
	bmih.biSizeImage = 0;
	bmih.biXPelsPerMeter = 0;
	bmih.biYPelsPerMeter = 0;
	bmih.biClrUsed = 0;
	bmih.biClrImportant = 0;

	// Allocate a region of memory for our fire and store its handle
	m_hBmp = CreateDIBSection(NULL, (BITMAPINFO *) &bmih, 0, (void **) &pBits, NULL, 0);

	if(m_hBmp == NULL)
		throw Exception("Could not allocate DIB section");

   	// Pass address of buffer to fire routine
	InitFire(pBits);

	// Get a memory DC
	m_hMemDC = CreateCompatibleDC(Canvas->Handle);
	SelectObject(m_hMemDC, m_hBmp);

    // Adjust height of form
    ClientHeight = HEIGHT + StatusBar->Height + ToolBar->Height;
    ClientWidth = WIDTH;

    m_dwFrames = 0;
}
//---------------------------------------------------------------------------

__fastcall TMainForm::~TMainForm()
{
    DeleteDC(m_hMemDC);
    DeleteObject(m_hBmp);
}

void __fastcall TMainForm::Draw(TObject *Sender, bool &Done)
{
   // Generate the fire and copy into our window, stretching as necessary
   DrawFire();
   StretchBlt(Canvas->Handle, 0, 0, ClientWidth, ClientHeight-StatusBar->Height,
              m_hMemDC, 0, 0, WIDTH, HEIGHT, SRCCOPY);
   m_dwFrames++;
   Done = false;
}

void __fastcall TMainForm::FormCreate(TObject *Sender)
{
     // Draw the fire when there's nothing else to do
     Application->OnIdle = Draw;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::TimerTimer(TObject *Sender)
{
     char szFPS[10];

     // Update the FPS display on the status bar
     snprintf(szFPS, sizeof(szFPS), "%d FPS", m_dwFrames*2);

     StatusBar->SimpleText = szFPS;

     m_dwFrames = 0;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::AboutExecute(TObject *Sender)
{
     AboutBox->ShowModal();
}
//---------------------------------------------------------------------------


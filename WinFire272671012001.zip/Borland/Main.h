//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ActnList.hpp>
#include <ImgList.hpp>
#include <ToolWin.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
    TTimer *Timer;
    TStatusBar *StatusBar;
    TToolBar *ToolBar;
    TActionList *ActionList1;
    TImageList *ImageList;
    TAction *About;
    TToolButton *ToolButton1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall TimerTimer(TObject *Sender);
    void __fastcall AboutExecute(TObject *Sender);

private:	// User declarations
            HBITMAP m_hBmp;
            HDC m_hMemDC;
            DWORD m_dwFrames;
void __fastcall Draw(TObject *Sender, bool &Done);

public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
        __fastcall ~TMainForm();
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif

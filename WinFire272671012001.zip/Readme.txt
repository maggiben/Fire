::::: WinFire :::::
Eugene Ciloci
ciloci@sympatico.ca
September 4, 2001

::::: Revisions :::::

Sept 8: Added multithreaded version
Sept 15: Added sizing grip to status bar when window is sizeable
Oct 1: Added Borland C++ Builder version

::::: Description :::::
A windows port of a very realistic fire algorithm originally coded by Frank Jan Sorensen Alias:Frank Patxi (fjs@lab.jt.dk)

Translated from Pascal to C++ and ported to Win32.

Everywhere you look on the net there's a fire algorithm.  The problem is that they're all based on real-mode DOS or written for Windows 3.1.  This means that all the DOS ones are fullscreen and sometimes the Windows 3.1 and DOS versions won't work at all.  I wanted to write a fire routine that worked on what everyone is using these days: Windows (>3.1).  I found this very nice fire routine written by Frank and decided to port it to Windows.

::::: Files :::::
BURN.PAS 	- Original Pascal fire code
Microsoft	- MS Visual C++ projects
	WinFire\	- Single threaded version
		Fire.cpp	- Fire drawing routines.  Just give it a memory region to draw 				to.  Display independant
		Fire.h		- Constants, etc
		Main.cpp	- Handles all the windows stuff.
		
	WinFireMT\	- Multi-threaded version
Borland		- Borland C++ Builder project

::::: Legal Stuff :::::
Feel free to distribute this as you wish but please credit me and the original coder of the algorithm.
Have Fun!


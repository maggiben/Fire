//**************************************************************************************************
//**FIRE.C Fire Effect By Dr.Kaos Matthew Pearce 30-07-97 (totally unoptimised!!!!!)
//**************************************************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define YSTART          100
#define XSTART          150
#define XEND            170
#define FIRESTRENGTH    15

//**************************************************************************************************
//**Globals*****************************************************************************************
//**************************************************************************************************

char *screen;

void setRGBcol(int col, int r, int g, int b);
void dofire();
void doquit();

//**************************************************************************************************
//**Some inline asm functions for mode 13h**********************************************************
//**************************************************************************************************

extern void setVGA();
#pragma aux setVGA = \
    "mov    ax, 13h" \
    "int    10h" \
    modify [eax];

extern void setText();
#pragma aux setText = \
    "mov    ax, 03h" \
    "int    10h" \
    modify [eax];
        
//**************************************************************************************************
//**main********************************************************************************************
//**************************************************************************************************

void main()
{
    int i;
    screen = (char *)0xa0000;
    
    setVGA();
    // set colour 
    for(i = 0; i<64; i++)
        setRGBcol(i, 0, 0, 0);          // black - black
    for(i = 64; i<128; i++)
        setRGBcol(i, i-64, 0, 0);       // black - red
    for(i = 128; i<192; i++)
        setRGBcol(i, 63, i-128, 0);     // red - yellow
    for(i = 192; i<255; i++)
        setRGBcol(i, 63, 63, i-192);    // yellow - white

    setRGBcol(255, 0, 0, 0);            // 255 - black
    for(i = 0; i<320; i++)
        screen[(199<<8) + (199<<6) + i] = 255;
                
    while(!kbhit())
    {
        dofire();
    }

    for(i = 0; i<320; i++)
        screen[(199<<8) + (199<<6) + i] = 0;
    
    for(i = 0; i<35; i++) doquit();
    setText();
}

void dofire()
{
    int x, y;

    // make a small fire at bottom of screen	
    for(x = XSTART; x<XEND; x++)
    {
        if(rand()%FIRESTRENGTH>1) 
            screen[(198<<8) + (198<<6) + x] = 255;     
        else         
            screen[(198<<8) + (198<<6) + x] = 0;        
    }

    // blur screen and feed fire :)	
    for(y = 198; y>YSTART; y--)
    {        
        for(x = XSTART; x<XEND; x++)
        {
            screen[(y-1<<8) + (y-1<<6) + x] = screen[(y<<8) + (y<<6) + x-1] + screen[(y<<8) + (y<<6) + x+1] +
                                              screen[(y+1<<8) + (y+1<<6) + x] + screen[(y-1<<8) + (y-1<<6) + x] +
                                              screen[(y-1<<8) + (y-1<<6) + x-1] + screen[(y-1<<8) + (y-1<<6) + x+1] +
                                              screen[(y+1<<8) + (y+1<<6) + x-1] + screen[(y+1<<8) + (y+1<<6) + x+1] >> 3;
            if(screen[(y<<8) + (y<<6) + x] > 200) screen[(y<<8) + (y<<6) + x] -= 1;
            else if(screen[(y<<8) + (y<<6) + x] > 148) screen[(y<<8) + (y<<6) + x] -= 1;
            else if(screen[(y<<8) + (y<<6) + x] > 4) screen[(y<<8) + (y<<6) + x] -= 2;
        }
    }
}

void doquit()
{
    int x, y;
    
    for(y = 199; y>YSTART; y--)
    {        
        for(x = XSTART; x<XEND; x++)
        {
            screen[(y-1<<8) + (y-1<<6) + x] = screen[(y<<8) + (y<<6) + x-1] + screen[(y<<8) + (y<<6) + x+1] +
                                              screen[(y+1<<8) + (y+1<<6) + x] + screen[(y-1<<8) + (y-1<<6) + x] +
                                              screen[(y-1<<8) + (y-1<<6) + x-1] + screen[(y-1<<8) + (y-1<<6) + x+1] +
                                              screen[(y+1<<8) + (y+1<<6) + x-1] + screen[(y+1<<8) + (y+1<<6) + x+1] >> 3;

            if(screen[(y<<8) + (y<<6) + x] > 200) screen[(y<<8) + (y<<6) + x] -= 2;
            else if(screen[(y<<8) + (y<<6) + x] > 4) screen[(y<<8) + (y<<6) + x] -= 1;
        }
    }
}

void setRGBcol(int col, int r, int g, int b)
{
    outp(0x3c8, col);
    outp(0x3c9, r);
    outp(0x3c9, g);
    outp(0x3c9, b);
}

//**************************************************************************
//*                                                                        *
//*    CFLAMES2 by Kirk A. Baum     (Modex Version *FAST*)                 *
//*       This C program was addapted from a pascal program by M.D.Mackey. *
//*       It has been modified to half the resolution used by Mark and the *
//*       routines are in C with inline assembly.  The original code was   *
//*       written in Pascal with Inline assemby for mode 13h.              *
//*       As with Marks code, I release this code into the public domain.  *
//*       It may be freely distributed and modified, but please give credit*
//*       where it is due if you use this code in your program.            *
//*       If you have any suggestions or comments please contact me at:    *
//*       kbaum@Novell.com.                                                *
//*       Mark can be reached at: mackey@aqueous.ml.csiro.au               *
//*                                                                        *
//**************************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>

void setmodex(void);
void setpalette(void);

int p1[56][80];
unsigned int i,j,k,l;
int delta;
char ch;
unsigned char pal[768]={  0,  0,  0,  0,  0, 24,  0,  0, 24,  0,  0, 28,
			  0,  0, 32,  0,  0, 32,  0,  0, 36,  0,  0, 40,
			   8,  0, 40, 16,  0, 36, 24,  0, 36, 32,  0, 32,
			  40,  0, 28, 48,  0, 28, 56,  0, 24, 64,  0, 20,
			  72,  0, 20, 80,  0, 16, 88,  0, 16, 96,  0, 12,
			 104,  0,  8,112,  0,  8,120,  0,  4,128,  0,  0,
			 128,  0,  0,132,  0,  0,136,  0,  0,140,  0,  0,
			 144,  0,  0,144,  0,  0,148,  0,  0,152,  0,  0,
			 156,  0,  0,160,  0,  0,160,  0,  0,164,  0,  0,
			 168,  0,  0,172,  0,  0,176,  0,  0,180,  0,  0,
			 184,  4,  0,188,  4,  0,192,  8,  0,196,  8,  0,
			 200, 12,  0,204, 12,  0,208, 16,  0,212, 16,  0,
			 216, 20,  0,220, 20,  0,224, 24,  0,228, 24,  0,
			 232, 28,  0,236, 28,  0,240, 32,  0,244, 32,  0,
			 252, 36,  0,252, 36,  0,252, 40,  0,252, 40,  0,
			 252, 44,  0,252, 44,  0,252, 48,  0,252, 48,  0,
			 252, 52,  0,252, 52,  0,252, 56,  0,252, 56,  0,
			 252, 60,  0,252, 60,  0,252, 64,  0,252, 64,  0,
			 252, 68,  0,252, 68,  0,252, 72,  0,252, 72,  0,
			 252, 76,  0,252, 76,  0,252, 80,  0,252, 80,  0,
			 252, 84,  0,252, 84,  0,252, 88,  0,252, 88,  0,
			 252, 92,  0,252, 96,  0,252, 96,  0,252,100,  0,
			 252,100,  0,252,104,  0,252,104,  0,252,108,  0,
			 252,108,  0,252,112,  0,252,112,  0,252,116,  0,
			 252,116,  0,252,120,  0,252,120,  0,252,124,  0,
			 252,124,  0,252,128,  0,252,128,  0,252,132,  0,
			 252,132,  0,252,136,  0,252, 136,   0,252, 140,   0,
			 252, 140,   0,252, 144,   0,252, 144,   0,252, 148,   0,
			 252, 152,   0,252, 152,   0,252, 156,   0,252, 156,   0,
			 252, 160,   0,252, 160,   0,252, 164,   0,252, 164,   0,
			 252, 168,   0,252, 168,   0,252, 172,   0,252, 172,   0,
			 252, 176,   0,252, 176,   0,252, 180,   0,252, 180,   0,
			 252, 184,   0,252, 184,   0,252, 188,   0,252, 188,   0,
			 252, 192,   0,252, 192,   0,252, 196,   0,252, 196,   0,
			 252, 200,   0,252, 200,   0,252, 204,   0,252, 208,   0,
			 252, 208,   0,252, 208,   0,252, 208,   0,252, 208,   0,
			 252, 212,   0,252, 212,   0,252, 212,   0,252, 212,   0,
			 252, 216,   0,252, 216,   0,252, 216,   0,252, 216,   0,
			 252, 216,   0,252, 220,   0,252, 220,   0,252, 220,   0,
			 252, 220,   0,252, 224,   0,252, 224,   0,252, 224,   0,
			 252, 224,   0,252, 228,   0,252, 228,   0,252, 228,   0,
			 252, 228,   0,252, 228,   0,252, 232,   0,252, 232,   0,
			 252, 232,   0,252, 232,   0,252, 236,   0,252, 236,   0,
			 252, 236,   0,252, 236,   0,252, 240,   0,252, 240,   0,
			 252, 240,   0,252, 240,   0,252, 240,   0,252, 244,   0,
			 252, 244,   0,252, 244,   0,252, 244,   0,252, 248,   0,
			 252, 248,   0,252, 248,   0,252, 248,   0,252, 252,   0,
			 252, 252,   4,252, 252,   8,252, 252,  12,252, 252,  16,
			 252, 252,  20,252, 252,  24,252, 252,  28,252, 252,  32,
			 252, 252,  36,252, 252,  40,252, 252,  40,252, 252,  44,
			 252, 252,  48,252, 252,  52,252, 252,  56,252, 252,  60,
			 252, 252,  64,252, 252,  68,252, 252,  72,252, 252,  76,
			 252, 252,  80,252, 252,  84,252, 252,  84,252, 252,  88,
			 252, 252,  92,252, 252,  96,252, 252, 100,252, 252, 104,
			 252, 252, 108,252, 252, 112,252, 252, 116,252, 252, 120,
			 252, 252, 124,252, 252, 124,252, 252, 128,252, 252, 132,
			 252, 252, 136,252, 252, 140,252, 252, 144,252, 252, 148,
			 252, 252, 152,252, 252, 156,252, 252, 160,252, 252, 164,
			 252, 252, 168,252, 252, 168,252, 252, 172,252, 252, 176,
			 252, 252, 180,252, 252, 184,252, 252, 188,252, 252, 192,
			 252, 252, 196,252, 252, 200,252, 252, 204,252, 252, 208,
			 252, 252, 208,252, 252, 212,252, 252, 216,252, 252, 220,
			 252, 252, 224,252, 252, 228,252, 252, 232,252, 252, 236,
			 252, 252, 240,252, 252, 244,252, 252, 248,252, 252, 252};


//************************************************************************
//*************************************************************************
void setmodex()
{
asm CLD
asm MOV AX,13h
asm INT 10h
asm CLI
asm MOV DX,3c4h
asm MOV AX,604h;//                 ; "Unchain my heart". And my VGA...
asm OUT DX,AX
asm MOV AX,0F02h;//                ; All planes
asm OUT DX,AX

asm MOV DX,3D4h
asm MOV AX,14h;//                  ; Disable dword mode
asm OUT DX,AX
asm MOV AX,0E317h;//               ; Enable byte mode.
asm OUT DX,AX
asm MOV AL,9
asm OUT DX,AL
asm INC DX
asm IN  AL,DX
asm AND AL,0E0h;//                 ; Duplicate each scan 8 times.
asm ADD AL,7
asm OUT DX,AL
}


//*************************************************************************
//*************************************************************************
void setpalette()
{
int  i;

for(i=0;i<768;i++)
   {
   pal[i] = pal[i] >> 2;
   }

 _SI = (unsigned int)&pal[0];
 asm mov cx,768
 asm mov dx,0x03c8
 asm xor al,al
 asm out dx,al
 asm inc dx
l1:
 asm outsb
 asm dec cx
 asm jnz l1
}


//*************************************************************************
//*************************************************************************
void main()
{
  setmodex();
  setpalette();
  randomize();
  ch=' ';

  // Initialize the screen buffer
  for(i=0;i<56;i++)
     {
     for(j=0;j<80;j++)
	{
	p1[i][j]=0;
	}
     }

  // Loop until the escape key has been pressed
  while(ch != 27)
     {

     // transform the current buffer
     asm mov cx,4399;
     _DI = (unsigned int)&p1[0][0];
     asm xor ax,ax
     asm add di,160
D1:
     asm mov ax,ds:[di-2]
     asm add ax,ds:[di]
     asm add ax,ds:[di+2]
     asm add ax,ds:[di+160]
     asm shr ax,2
     asm jz D2

     asm sub ax,1
     asm jz D2
     asm sub ax,1
     asm jz D2
     asm sub ax,1

D2:
     asm mov word ptr ds:[di-160],ax
     asm add di,2
     asm dec cx
     asm jnz D1;


     // Set new bottom line with random white or black color
     delta = 0;
     for(j=0;j<80;j++)   // {set new bottom line}
	{
	if(random(10) < 5)
	  {
	  delta=random(2)*255;
	  }
	p1[54][j]=delta;
	p1[55][j]=delta;
	}


     // Write buffer to the screen
     _SI = (unsigned int)&p1[0][0];
     asm mov di,0
     asm mov ax,0A000h
     asm mov es,ax
     asm mov cx,40*50
F1:
     asm mov ax,ds:[si]
     asm add si,2
     asm mov dl,al
     asm mov ax,ds:[si]
     asm add si,2
     asm mov dh,al
     asm mov es:[di],dx
     asm add di,2
     asm dec cx
     asm jnz F1


     if(kbhit())
       {
       ch=getch();
       }
     }

  // Restore the screen to text mode
  asm mov ax,03h
  asm int 10h
}
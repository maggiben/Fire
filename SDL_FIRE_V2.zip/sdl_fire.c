// #######################################################################################
// # gcc -o fire sdl_fire.c `sdl-config --cflags --libs`
// #
// # 16-bit DOS TurboC "fire" routine converted to use SDL libraries
// #######################################################################################

/*
Copyright (C) 1999-2002 Bo Stout

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

Bo Stout crafoo@yahoo.com, detox@crushingabyss.com
*/

#include <stdlib.h>
#include <math.h>
#include "SDL.h"


void color_scale( int, int, int, int, int, int, int, int, SDL_Color * );


int main(int argc, char *argv[])
{
	// SDL library display framebuffer
	SDL_Surface *screen;

	// SDL library palette structure (basiclly int red, int green, int blue)
	SDL_Color palette[ 256 ];

	// SDL library event structure - pointer-chain of structures containing pending input events
	SDL_Event event;

	int i, j, p;


	// We want to call SDL_Quit() when we exit() from main{}
	atexit( SDL_Quit );

	// Startup SDL library audio and video functions
	if ( SDL_Init( SDL_INIT_AUDIO | SDL_INIT_VIDEO ) < 0 ) {
		fprintf( stderr, "Unable to init SDL: %s\n", SDL_GetError() );
		exit( 1 );
	}

	// Get frambuffer pointer to 640x480 res screen with 256 colors using a hardware palette
	screen = SDL_SetVideoMode( 640, 480, 8, SDL_HWPALETTE|SDL_SWSURFACE );
	if( screen == NULL ) {
		fprintf( stderr, "Unable to set 640x480x256 video: %s\n", SDL_GetError() );
	}

	// Set hardware palette values

        color_scale( 0, 0, 0, 190, 100, 100, 0, 72, palette );       //smoke->orange
        color_scale( 255, 50, 50, 255, 190, 0, 73, 105, palette );   //orange->yellow
        color_scale( 255, 190, 0, 255, 255, 0, 106, 150, palette );  //yellow->white
        color_scale( 255, 255, 0, 255, 255, 255, 151, 255, palette );

	SDL_SetPalette( screen, SDL_PHYSPAL|SDL_LOGPAL, palette, 0, 256 );

	while( 1 == 1 ) {

	// Get events until there are no more.
	while( SDL_PollEvent( &event ) == 1 ) {

		// Was a key was pressed?
		if( event.type == SDL_KEYDOWN ) {

			// Was it the escape key?
			if( event.key.keysym.sym == SDLK_ESCAPE ) {
				sprintf( stderr, "Keyboard request: exit\n\n" );
				exit( 0 );
			}
		}
	}

	// Get ready to do direct buffer writting: lock the buffer
	SDL_LockSurface( screen );

	// Generate random line
	for( i = 1; i < 639; i++ ) {

		*( Uint8 * ) ( screen->pixels + i + 640 * 450 ) = 255 * rand();
		*( Uint8 * ) ( screen->pixels + i + 640 * 451 ) = 128;
	}

	// Apply modified blur function to video buffer

	for( i = 1; i < 638; i++ ) {

		for( j = 0; j < 478; j++ ) {

			p = *( Uint8 * ) ( screen->pixels + i + 640 * j + 640 ) +
			    *( Uint8 * ) ( screen->pixels + i + 640 * j + 1280 ) +
			    *( Uint8 * ) ( screen->pixels + i + 640 * j + 641 ) +
			    *( Uint8 * ) ( screen->pixels + i + 640 * j + 639 );
			p = p / 4;
			if( p > 255 ) p = 255;

			*( Uint8 * ) ( screen->pixels + j * 640 + i ) = p;
		}
	}


	// We are done doing direct buffer access: unlock the buffer
	SDL_UnlockSurface( screen );

	// Update video display
	SDL_UpdateRect( screen, 0, 0, 640, 480 );

	}

	exit( 0 );
}


void color_scale( int start_red, int start_green, int start_blue,
                                  int end_red, int end_green, int end_blue,
                                  int start, int end, SDL_Color *color_buffer )
{
        int loop;
        double delta_red, delta_green, delta_blue;
        double red, green, blue;

        red = start_red;
        green = start_green;
        blue = start_blue;

        delta_red = (double) ( end_red - start_red ) / ( end - start );
        delta_green = (double) ( end_green - start_green ) / ( end - start );
        delta_blue = (double) ( end_blue - start_blue ) / ( end - start );

        for( loop = start; loop <= end; loop++ ) {

                color_buffer[ loop ].r = ( Uint8 ) red;

                color_buffer[ loop ].g = ( Uint8 ) green;

                color_buffer[ loop ].b = ( Uint8 ) blue;

                red += delta_red;
                green += delta_green;
                blue += delta_blue;
        }
}


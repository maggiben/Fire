Title: Fireworks ( SetDIBitsToDevice )
Description: I found a java class called "jahabi.class" which diplayed excellent fireworks. I decomiled it and changed it over to C++. This will show you how to render a bitmap using SetDIBitsToDevice() and creating a bitmap using CreateDIBSection(). This shows you how to manipulate a bitmap's bits in memory. Great for fast processing of graphic effects. (does not use DirectX or OpenGL)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6331&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

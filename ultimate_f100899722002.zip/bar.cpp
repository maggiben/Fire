unsigned char*p=(unsigned char*)MK_FP(0xa000,0);
void wait()
{
asm    mov dx,3DAh
l1:
 asm   in al,dx
 asm   and al,08h
 asm   jnz l1
l2:
 asm   in al,dx
 asm   and al,08h
  asm  jz  l2
  }
 void setg()
 {
 asm mov ax,0x013;
 asm INT 10h;
 }
 void setext()
 {
 asm mov ax,0x0003;
 asm INt 10h;
 }
 void replace(int &x,int &y)
 {
 int temp;
 if(x>y)
 {
 temp=x;
 x=y;
 y=temp;
 }
 }
 void vline(int x,int y1,int y2,int c,unsigned char*t=p)
 {
 for(int i=y1;i<=y2;i++)
 *(t+x+i*320)=c;
 }
 void box(int x1,int y1,int x2,int y2,int c,unsigned char*t=p)
 {
 replace(x1,x2);
 replace(y1,y2);
 memset(t+x1+y1*320,c,x2-x1);
 memset(t+x1+y2*320,c,x2-x1);
 vline(x1,y1,y2,c);
 vline(x2,y1,y2,c);
 }
 void fbox(int x1,int y1,int x2,int y2,int c,unsigned char*t=p)
 {
 replace(x1,x2);
 replace(y1,y2);
 for(int i=y1;i<=y2;i++)
 memset(t+x1+i*320,c,x2-x1);
 }
 void bar3d(int x1,int y1,int x2,int y2,int c,unsigned char*t=p)
 {
 replace(x1,x2);
 replace(y1,y2);
 fbox(x1,y1,x2,y2,c);
 //fbox(x1+3,y1+3,x2-3,y2-3,c-1);
 memset(t+x1+y1*320,15,x2-x1);
 memset(t+x1+y2*320,10,x2-x1+1);
 vline(x1,y1,y2-1,10);
 vline(x2,y1,y2-1,15);
 }
 void write(int c,int r,int g,int b)
 {
 outp(0x03c8,c);
 outp(0x03c9,r);
  outp(0x03c9,g);
   outp(0x03c9,b);
   }
   void read(int c,int &r,int &g,int &b)
   {
   outp(0x03c7,c);
   r=inp(0x03c9);
      g=inp(0x03c9);
	 b=inp(0x03c9);
	 }
     void rotpal(int st,int en)
     {
     int r,g,b,r1,g1,b1;
     read(st,r,g,b);
     for(int i=st;i<en;i++)
     {
     read(i+1,r1,g1,b1);
     write(i,r1,g1,b1);
     }
     write(en,r,g,b);
     }
    inline void change(int c,int d)
     {
     int r,g,b,r1,g1,b1;
     //read(c,r,g,b);
      read(d,r1,g1,b1);
      write(c,r1,g1,b1);
     // write(d,r,g,b);
      }
unsigned char* readpcx(char*fname,int &w,int &h)
{
int x,y,xm,ym;
FILE *fp=fopen(fname,"rb");
fseek(fp,4L,SEEK_SET);
fread(&xm,1,2l,fp);
fread(&ym,1,2l,fp);
fread(&x,1,2L,fp);
fread(&y,1,2L,fp);
w=x-xm+1;
h=y-ym+1;
unsigned char*t=(unsigned char*)malloc(w*h);
memset(p,0,w*h);
char pall[768];
fseek(fp,-768L,SEEK_END);
fread(pall,768L,1,fp);
for(long i=0;i<768;i++)
pall[i]/=4;
for(i=0;i<255;i++)
write(i,pall[3*i],pall[3*i+1],pall[3*i+2]);
fseek(fp,128L,SEEK_SET);
int l;long l1=(long)w*h;
unsigned char ch;
for(i=0;i<l1; )
{
 ch=fgetc(fp);
  if(ch<192)
 {
 *(t+i)=ch;
 i++;
 }
 else
 {
 l=ch-192;
 ch=fgetc(fp);
 for( ;l>0&&i<l1;l--)
 {
 *(t+i)=ch;
 i++;
 }
 }
 }
 fclose(fp);
 return t;
 }
 void writepcx(unsigned char*source,unsigned char*dest,int w,int h)
 {
   for(int i=0;i<h;i++)
   memmove(dest+i*320,source+i*w,w);
   }
void fadeup()
{
int pall[256][3];
for(int j=0;j<64;j++)
wait();
{
for(int i=0;i<256;i++)
{
read(i,pall[i][0],pall[i][1],pall[i][2]);
if(pall[i][0]<63) pall[i][0]++;
if(pall[i][1]<63) pall[i][1]++;
if(pall[i][2]<63) pall[i][2]++;

write(i,pall[i][0],pall[i][1],pall[i][2]);
}

}
}
unsigned char*readbmp(char*filename,int &w,int&h)
{
FILE *fp;
int col;
fp=fopen(filename,"rb");
if(fgetc(fp)!='B'||fgetc(fp)!='M')
{
fclose(fp);
return NULL;
}
fseek(fp,16,SEEK_CUR);
fread(&w,2,1,fp);
fgetc(fp);
fgetc(fp);
fread(&h,2,1,fp);
fseek(fp,22,SEEK_CUR);
fread(&col,2,1,fp);
fseek(fp,6,SEEK_CUR);
unsigned char*t=(unsigned char*)malloc(w*h);
//fseek(fp,col*4,SEEK_CUR);
for(int i=0;i<col;i++)
{
write(i,fgetc(fp)>>2,fgetc(fp)>>2,fgetc(fp)>>2);
fgetc(fp);
}
for(int j=h-1;j>=0;j--)
for(i=0;i<w;i++)
*(t+i+j*w)=fgetc(fp);
fclose(fp);
return t;
}
void fadedown()
{
char pall[256][3];
for(int j=0;j<64;j++)
wait();
{
for(int i=0;i<256;i++)
{
read(i,pall[i][0],pall[i][1],pall[i][2]);
if(pall[i][0]>0) pall[i][0]--;
if(pall[i][1]>0) pall[i][1]--;
if(pall[i][2]>0) pall[i][2]--;

write(i,pall[i][0],pall[i][1],pall[i][2]);
}

}
}
void button(int x1,int y1,int x2,int y2,unsigned char*t=p)
{
fbox(x1,y1,x2,y2,7,t);
memset(t+x1+y1*320,15,x2-x1);
memset(t+x1+y2*320,0,x2-x1);
vline(x1,y1,y2-1,15,t);
vline(x2,y1,y2,0,t);
}
int pow(int x,int y)
{
int a=1;
for(int i=0;i<y;i++)
a*=x;
return a;
}
void drawchar(char c1,int x,int y,int co,unsigned char*t1=p)
{
unsigned char*t=(unsigned char*)MK_FP(0xf000,0xfa6e);
int l=0,c,d;
for(int i=0;i<8;i++)
{
c=*(t+c1*8+l);
for(int j=0;j<8;j++)
{
d=c&(int)pow(2,7-j);
if(d==0);
//*(t1+10+j+x+(i+y)*320)=0;
else
*(t1+10+j+x+(i+y)*320)=co;//*(t+65*8+l++);
}
l++;// co-=2;
}
//memmove(p,t+65*8,64);
//getch();
//setext();
}
void line(int x1,int y1,int x2,int y2,unsigned char*t=p)
 {
  float m=(y2-y1)*1.0/(x2-x1);
  for(int i=x1;i<x2;i++)
  {
  float y=m*i;
  *(t+i+(int)y*320)=2;
  }
  }
/* void circle(int x,int y,int r,char color,unsigned char*t=p)
  {
   float x1,y1,angle=0;
   do
   {
   x1=x+r*cos(angle);
   y1=y+r*sin(angle);
   angle+=0.005;
    *(t+(int)x1+(int)y1*320)=color;
   }
   while(angle<6.28);
   }    */
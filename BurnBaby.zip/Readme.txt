joe dortch
borland game programming contest entry
burn baby burn!

BurnBaby.pas is a Delphi unit that exports a global instance of a TBurner class named Burner.  Burner provides two methods:  BurnControls and RestoreControls.  The only parameter to both methods is an array of TWinControls.  Burner also provides a BurnSpeed property.  ONE is fastest, the higher the number, the slower the burn.

BurnControls:  Begins burning the specified WinControls.  When they have burned completely up, they disappear.
RestoreControls:  Used to display the controls again after they have burned up.

The demo program demonstrates using this Burner to burn various Controls on a form.  Simply press the buttons on the green panel and watch the fireworks.


OK, this is a pretty cheesy little attempt at a contest entry and it's not technically a "Component," but it looks pretty cool, i think.  I can imagine all sorts of uses for something like this in a video game (though it deals more with the interface than with the game itself).  Particularly since it would be a very simple matter to modify the bitmaps included and replace the "burn" effect with any of a variety of other interesting effects (such as being eaten away by acid or teleported out, Star Trek style... the possibilities are endless).  Also, a Win API programmer will notice that it would be a fairly simple matter to convert this to use only Window Handles rather than actual TWinControls.  that being the case, this could be used to burn controls on ANY windowed control -- even one not owned by your application (though, undoubtedly, MicroSoft would discourage this practice as being "impolite").

well, i'm not sure if this thing even technically meets the contest criteria, but i think it's a fun little gadget anyway.  i don't have a copy of Delphi 5 yet, so i can only hope and pray that this will compile.  i can say that it works fine in Delphi 4, and runs on Win 95, 98, and NT.

thanks for having the fun contest!

-joe

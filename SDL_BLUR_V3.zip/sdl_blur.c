// #######################################################################################
// # 2D Pixel Feedback / Motion Blur Experiment V.3
// # Based on blur.cpp written and (C) Copyrighted 1995 Bo Stout
// # 20x20 byte BMP ball sprite
// # ANSI C I/O with SDL graphic, event, and graphic file I/O routines
// # Parts of gfx code hard-coded to 8-bitplane graphics (256 colors)
// # fixed point math throughout
// # v3 - 60Hz screen update timer function added
// #
// # gcc -o blur sdl_blur.c `sdl-config --cflags --libs`
// #
// # 16-bit DOS TurboC blur routine converted to use SDL libraries
// #######################################################################################

/*
Copyright (C) 1999-2005 Bo Stout

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

Bo Stout crafoo@yahoo.com, detox@crushingabyss.com
*/

#include <stdlib.h>
#include <math.h>
#include "SDL.h"


// Framebuffer parameters
#define BUFFERX		640
#define BUFFERY		480
#define BITPLANES	8

// 'blur' code view area information
#define HSTART		30		// horizontal offset - border to add to both sides of blur area
#define VSTART		30		// vertical offset - "
#define HSIZE		600		// pixel width of blur area
#define VSIZE		440		// pixel height of blur area

#define UPDATEFRQ   60          // maximum # of times the screen will refresh every second

// ball sprite information
#define SPRITEFILENAME	"blur_sprite.bmp"
#define BALLS		50		// number of ball sprites to draw
#define BSIZEX		20		// pixel size of ball sprite - x dimension
#define BSIZEY		20		// pixel size of ball sprite - y dimension



// ball sprite movement variables
int xydata[ BALLS * 2 ];
int xyspeed[ BALLS * 2 ];

// Rectangle structure to hold sprite location in framebuffer
SDL_Rect location = { 0, 0, BSIZEX, BSIZEY };

// SDL library display framebuffer
SDL_Surface *screen;

// SDL surface to hold sprite image
SDL_Surface *ball;

// SDL library palette structure (basiclly int red, int green, int blue)
SDL_Color palette[ 256 ];




void color_scale( int, int, int, int, int, int, int, int, SDL_Color * );


Uint32 EVNT_updatescreen( Uint32 interval, void *param )
{
    int i, j, p;



    // Update sprite position/speed data
    for( i = 0; i < BALLS * 2; i += 2 ) {
        if( xydata[ i ] > ( HSIZE + HSTART - BSIZEX ) || xydata[ i ] < ( HSTART - BSIZEX / 2 )  )
                            xyspeed[ i ] = -xyspeed[ i ];

                    if( xydata[ i + 1 ] < ( VSTART - BSIZEY / 2 ) || xydata[ i + 1 ] > ( VSIZE + VSTART - BSIZEY ) )
                            xyspeed[ i + 1 ] = -xyspeed[ i + 1 ];

                    //update x, y position
                    xydata[ i ] += xyspeed[ i ];
                    xydata[ i + 1 ] += xyspeed[ i + 1 ];

        location.x = xydata[ i ];
        location.y = xydata[ i + 1 ];

                // Stamp down the sprites in their new location
        if( SDL_BlitSurface( ball, NULL, screen, &location ) < 0 )
            fprintf( stderr, "BlitSurface error: %s\n", SDL_GetError() );
    }
            // Get ready to do direct buffer writting: lock the buffer.
            SDL_LockSurface( screen );

    // Apply modified blur function to video buffer - symmetric about calculated point.
    for( i = 4; i < 636; i++ ) {
        for( j = 4; j < 476; j++ ) {

            p = *( Uint8 * ) ( screen->pixels + i + 640 * j - 1 ) +
                *( Uint8 * ) ( screen->pixels + i + 640 * j + 1 ) +
                *( Uint8 * ) ( screen->pixels + i + 640 * j - 640 ) +
                *( Uint8 * ) ( screen->pixels + i + 640 * j + 640 );
            p = p / 4;
            if( p > 255 ) p = 255;

            *( Uint8 * ) ( screen->pixels + j * 640 + i ) = p;
        }
    }


    // We are done doing direct buffer access: unlock the buffer.
    SDL_UnlockSurface( screen );

    // Update video display.
    SDL_UpdateRect( screen, 0, 0, 0, 0 );
}



int main(int argc, char *argv[])
{

	// SDL library event structure - pointer-chain of structures containing pending input events
	SDL_Event event;

    // timer event ID
    SDL_TimerID screentimer;

	int i, j;
	int key_code = SDLK_HOME;


	// Startup SDL library audio and video functions
	if ( SDL_Init( SDL_INIT_TIMER | SDL_INIT_VIDEO ) < 0 ) {
		fprintf( stderr, "Unable to init SDL: %s\n", SDL_GetError() );
		return( -1 );
	}
	fprintf( stderr, "SDL library opened.\n" );

	screentimer = SDL_AddTimer( (Uint32) ( 1000.0 / UPDATEFRQ ), EVNT_updatescreen, NULL );
	if( screentimer == NULL ) {
	    fprintf( stderr, "Error adding screen update timer function.\n" );
	    return( -9 );
	}

	// We want to call SDL_Quit() when we exit() from main{}
	atexit( SDL_Quit );

	// Get frambuffer pointer to 640x480 res screen with 256 colors using a hardware palette
	screen = SDL_SetVideoMode( 640, 480, 8, SDL_HWPALETTE|SDL_SWSURFACE );
	if( screen == NULL ) {
		fprintf( stderr, "Unable to set 640x480x256 video: %s\n", SDL_GetError() );
	}
    fprintf( stderr, "SDL framebuffer allocated to 640x480x256 bitmap.\n" );

	// Load ball sprite from .bmp file
	ball = (SDL_Surface *) SDL_LoadBMP( SPRITEFILENAME );
	if ( ball == NULL ) {
        	fprintf( stderr, "Couldn't load ball sprite image: %s\n", SDL_GetError() );
        	return( -2 );
	}
	fprintf( stderr, "Sprite file loaded.\n" );


        // Initialize the sprite movement data
        srand( 1000 );  // random number seed
        for( i = 0; i < BALLS * 2; i += 2 ) {

		// 10 pixel border around blur area
                xydata[ i ] = rand() % HSIZE + HSTART / 2;
                xydata[ i + 1 ] = rand() % VSIZE + VSTART / 2;

		//fprintf( stderr, "%d: ( %d, %d )    ", i, xydata[ i ], xydata[ i + 1 ] );

		// Setup sprite speeds
                xyspeed[ i ] = ( -rand() % 2 ) * 2 + rand() % 5;
                xyspeed[ i + 1 ] = ( -rand() % 2 ) * 2 + rand() % 5;
		if( abs( xyspeed[ i ] ) < 2 ) { xyspeed[ i ] += 2; xyspeed[ i ] *= 2; }
		if( abs( xyspeed[ i + 1 ] ) < 2 ) { xyspeed[ i + 1 ] += 2; xyspeed[ i + 1 ] *= 2; }

		fprintf( stderr, "array entry #%d V: (%d, %d )\n", i, xyspeed[ i ], xyspeed[ i + 1 ] );
        }
        fprintf( stderr, "Sprites initialized.\n" );

	// Set hardware palette values

        color_scale( 0, 0, 0, 100, 100, 100, 0, 25, palette );		//smoke
        color_scale( 190, 100, 100, 255, 50, 50, 26, 40, palette );	//transition
        color_scale( 255, 50, 50, 255, 190, 0, 41, 105, palette );	//reds
        color_scale( 255, 190, 0, 255, 255, 0, 106, 150, palette );	//yellows
        color_scale( 255, 255, 0, 255, 255, 255, 151, 255, palette );	//whites

	SDL_SetPalette( screen, SDL_PHYSPAL|SDL_LOGPAL, palette, 0, 256 );

	// Setup transparent pixel blitting
	SDL_SetColorKey( ball, SDL_SRCCOLORKEY, 0 );

	fprintf( stderr, "Hardware palette initialized and set.\n" );

	// Lock surface and draw a box around the periphery.
        // Get ready to do direct buffer writting: lock the buffer.
        SDL_LockSurface( screen );

	// Draw vertrical parts of display border.
	for( i = 0; i < BUFFERX - 1; i++ ) {
		for( j = 0; j < VSTART / 2; j++ ) {
			*( Uint8 * ) ( screen->pixels + i + j * BUFFERX ) = 255;
			*( Uint8 * ) ( screen->pixels + i + ( BUFFERY - 1 - j ) * BUFFERX ) = 255;
		}
	}

	// Draw horizontal parts of display border.
	for( i = 0; i < HSTART / 2; i++ ) {
		for( j = 0; j < BUFFERY - 1; j++ ) {
                        *( Uint8 * ) ( screen->pixels + i + j * BUFFERX ) = 255;
                        *( Uint8 * ) ( screen->pixels + ( BUFFERX - i - 1 ) + j * BUFFERX ) = 255;
		}
	}

        // We are done doing direct buffer access: unlock the buffer
        SDL_UnlockSurface( screen );

fprintf( stderr, "Display initialized.\n" );



	while( key_code != SDLK_ESCAPE ) {

		// Get events until there are no more.
		while( SDL_PollEvent( &event ) == 1 ) {

		    if( event.type == SDL_QUIT ) return( 0 );

			// Was a key was pressed?
			if( event.type == SDL_KEYDOWN ) {

				key_code = event.key.keysym.sym;
			}
		}
	}

	fprintf( stderr, "Keyboard request: exit\n\n" );
	if( ball != NULL ) SDL_FreeSurface( ball );
	if( screen != NULL ) SDL_FreeSurface( screen );
    SDL_Quit();
}


void color_scale( int start_red, int start_green, int start_blue,
                                  int end_red, int end_green, int end_blue,
                                  int start, int end, SDL_Color *color_buffer )
{
        int loop;
        double delta_red, delta_green, delta_blue;
        double red, green, blue;

        red = start_red;
        green = start_green;
        blue = start_blue;

        delta_red = (double) ( end_red - start_red ) / ( end - start );
        delta_green = (double) ( end_green - start_green ) / ( end - start );
        delta_blue = (double) ( end_blue - start_blue ) / ( end - start );

        for( loop = start; loop <= end; loop++ ) {

                color_buffer[ loop ].r = ( Uint8 ) red;

                color_buffer[ loop ].g = ( Uint8 ) green;

                color_buffer[ loop ].b = ( Uint8 ) blue;

                red += delta_red;
                green += delta_green;
                blue += delta_blue;
        }
}


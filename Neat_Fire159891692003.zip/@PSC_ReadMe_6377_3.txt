Title: Neat Fire
Description: I found this code compiled as a java applet on a website... i decompiled the applet with JAD and transferred it over to C++. This uses the same technique as the Fireworks code (http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?txtCodeId=6331&lngWId=3) i submitted last month. This is a really easy way to create a nice looking fire effect to add to your apps... maybe the about menu or something. Anyway, this uses CreateDibSection() and SetDIBitsToDevice() to create this nice flicker-free effect. Play with the settings, you can make diffrent basic effects. Original java source code included...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6377&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

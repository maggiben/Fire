// Decompiled by Jad v1.5.7g. Copyright 2000 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   fire.java

import java.applet.Applet;

public class fire extends tinyptc
{

    public void Main(int i, int j)
    {
        int k = Integer.parseInt(getParameter("sizeofpal"));
        int l = Integer.parseInt(getParameter("down"));
        int i1 = Integer.parseInt(getParameter("r1"));
        int j1 = Integer.parseInt(getParameter("g1"));
        int k1 = Integer.parseInt(getParameter("b1"));
        int l1 = Integer.parseInt(getParameter("r2"));
        int i2 = Integer.parseInt(getParameter("g2"));
        int j2 = Integer.parseInt(getParameter("b2"));
        int k2 = i * j;
        int ai[] = new int[k2];
        int ai1[] = new int[k2];
        int ai2[] = new int[k];
        for(int l2 = 0; l2 < k; l2++)
        {
            int j4 = k / 2;
            int i3;
            int k3;
            int i4;
            if(l2 < j4)
            {
                i3 = (i1 * l2) / j4;
                k3 = (j1 * l2) / j4;
                i4 = (k1 * l2) / j4;
            } else
            {
                i3 = ((l1 - i1) * (l2 - j4)) / j4 + i1;
                k3 = ((i2 - j1) * (l2 - j4)) / j4 + j1;
                i4 = ((j2 - k1) * (l2 - j4)) / j4 + k1;
            }
            ai2[l2] = i3 << 16 | k3 << 8 | i4;
        }

        do
        {
            for(int j3 = (k2 - (i << 2)) + 5; j3 < k2 - i * 3 - 5; j3 += 2)
                ai1[j3] = ai1[j3 + i] = ai1[j3 + 1] = ai1[j3 + i + 1] = noise() % k;

            for(int l3 = i; l3 < k2 - i * 3; l3++)
            {
                ai1[l3] = (ai1[l3 - 1] + ai1[l3] + ai1[l3 + 1] + ai1[(l3 + i) - 1] + ai1[l3 + i + 1] + ai1[(l3 + i + i) - 1] + ai1[l3 + i + i] + ai1[l3 + i + i + 1] >> 3) - l;
                if(ai1[l3] < 0)
                    ai1[l3] = 0;
                ai[l3] = ai2[ai1[l3]];
            }

            update(ai);
        } while(true);
    }

    private int noise()
    {
        int i = seed;
        i >>= 3;
        i ^= seed;
        int j = i & 0x1;
        i >>= 1;
        seed >>= 1;
        seed |= j << 30;
        return i;
    }

    public fire()
    {
        seed = 0x12345;
    }

    int seed;
    int ow;
    int oh;
}

// Fireworks.cpp : Defines the entry point for the application.
//

#define WIN32_LEAN_AND_MEAN

//
// includes
//
#include <windows.h>
#include <stdlib.h>
#include "resource.h"

//
// defines
//
#define STV_CLASS "shitfire_class"
#define STV_TITLE "Fire"
#define WND_WIDTH 420
#define WND_HEIGHT 130

//
// Global Variables
//
HINSTANCE	m_hInst = NULL;
HWND		m_hWnd = NULL;
BOOL		m_bInit = FALSE;

//
// Foward declarations of functions included in this code module:
//
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void OnCreate();
void OnRender();
void OnDestroy();

//
// pep
//
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow){

	m_hInst = hInstance;

	WNDCLASSEX wcex;
	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= m_hInst;
	wcex.hIcon			= LoadIcon(m_hInst, (LPCTSTR)IDI_FIREWORKS);
	wcex.hIconSm		= LoadIcon(m_hInst, (LPCTSTR)IDI_SMALL);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)COLOR_WINDOW;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= STV_CLASS;
	RegisterClassEx(&wcex);

	m_hWnd = CreateWindow(STV_CLASS,
						  STV_TITLE, 
						  WS_OVERLAPPED|WS_SYSMENU,
						  CW_USEDEFAULT, CW_USEDEFAULT, 
						  WND_WIDTH, WND_HEIGHT, 
						  NULL, NULL, 
						  m_hInst, NULL);

	ShowWindow(m_hWnd, nCmdShow);
	UpdateWindow(m_hWnd);

	MSG msg;
	while(TRUE){
		if(PeekMessage(&msg,NULL,0,0,PM_REMOVE)){
			if(msg.message == WM_QUIT){
				break;
			}else{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}else{
			if(m_bInit)
				OnRender();
		}

	}

	UnregisterClass(STV_CLASS,m_hInst);

	return msg.wParam;
}

//
// main window proc
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam){
	switch (message){
		case WM_CREATE:
			m_hWnd = hWnd;
			OnCreate();
			break;
		case WM_DESTROY:
			OnDestroy();
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// memory bitmap info
BITMAPINFO m_bmpInfo;
HDC m_hDC = NULL;
HBITMAP m_memBmp = NULL;
int* m_pBits = NULL;
int m_nNumPixels = 0;
int m_nPlacementX = 0;
int m_nPlacementY = 0;

//
// defines to make life easier
//
#define wnd_cx m_bmpInfo.bmiHeader.biWidth
#define wnd_cy (-m_bmpInfo.bmiHeader.biHeight)
#define MAX_FPS 40

//
//	fire setup
//
int pal_size = 256;		// palette size
int fire_height = 1;	// 0-tall fire, 1-smaller fire...

int i1 = 255;	// red - main
int j1 = 0;		// green - main
int k1 = 0;		// blue - main

int l1 = 255;	// red - coals
int i2 = 255;	// green - coals
int j2 = 0;		// blue - coals

int* work_area;	// work area
int* palette;	// palette

int seed = 0x12345; // seed for our own rand() (noise())

//
// On Creation
//
void OnCreate(){

	// set up placement
	m_nPlacementX = GetSystemMetrics(SM_CXSIZEFRAME);
	m_nPlacementY = GetSystemMetrics(SM_CYCAPTION)+GetSystemMetrics(SM_CYSIZEFRAME);
	int nWidth = WND_WIDTH - m_nPlacementX*2;
	int nHeight = WND_HEIGHT - m_nPlacementY - GetSystemMetrics(SM_CYSIZEFRAME);

	DWORD sizeOfBits = (((nWidth * 32 + 31) & ~31) >> 3) * nHeight;
	m_nNumPixels = sizeOfBits / sizeof(RGBQUAD);

	memset(&m_bmpInfo,0,sizeof(m_bmpInfo));
	m_bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	m_bmpInfo.bmiHeader.biWidth = nWidth;
	m_bmpInfo.bmiHeader.biHeight = -nHeight; // make negative for "right side up" bitmap
	m_bmpInfo.bmiHeader.biSizeImage = sizeOfBits;
	m_bmpInfo.bmiHeader.biPlanes = 1;
	m_bmpInfo.bmiHeader.biBitCount = 32;

	m_hDC = GetWindowDC(m_hWnd);
	m_memBmp = CreateDIBSection(m_hDC, &m_bmpInfo, DIB_RGB_COLORS, (void**)&m_pBits, NULL, 0);

	srand(GetTickCount());

	// set up palette
	palette = new int[pal_size];
    for(int l2 = 0; l2 < pal_size; l2++){
		int j4 = pal_size / 2;
		int i3, k3, i4;
		if(l2 < j4){
			i3 = (i1 * l2) / j4;
			k3 = (j1 * l2) / j4;
			i4 = (k1 * l2) / j4;
		}else{
			i3 = ((l1 - i1) * (l2 - j4)) / j4 + i1;
			k3 = ((i2 - j1) * (l2 - j4)) / j4 + j1;
			i4 = ((j2 - k1) * (l2 - j4)) / j4 + k1;
		}
        palette[l2] = i3 << 16 | k3 << 8 | i4;
    }

	// create work area
	work_area = new int[m_nNumPixels];

	// we are setup... kick in rendering function
	m_bInit = TRUE;
}

//
// On Destroy
//
void OnDestroy(){
	ReleaseDC(m_hWnd, m_hDC);	// done with DC
	::DeleteObject(m_memBmp);	// done with bitmap
	delete work_area;	// destroy work area
	delete palette;		// destory palette
}

//
// basically "rand()" function
//
int noise(){
	int i = seed;
	i >>= 3;
	i ^= seed;
	int j = i & 0x1;
	i >>= 1;
	seed >>= 1;
	seed |= j << 30;
	return i;
}

//
// On Render
//
void OnRender(){

	DWORD gtc = GetTickCount();

	// sync code
	static DWORD lastUpdate = 0;
	if(gtc >= lastUpdate + 1000/MAX_FPS){
		lastUpdate = gtc;
	}else{
		return;
	}

	// FPS timer
	static DWORD nextUpdate = 0;
	static int count = 0;
	if(nextUpdate < gtc){
		nextUpdate = gtc+1000;
		char fps[127]; wsprintf(fps,"%s [FPS: %i]", STV_TITLE, count);
		SetWindowText(m_hWnd,fps);
		count = 0;
	}else{
		++count;
	}

	//////////////////////////////
	//							//
	//////////////////////////////

	// init new row
    for(int j3 = (m_nNumPixels - (wnd_cx << 2)) + 5; j3 < m_nNumPixels - wnd_cx * 3 - 5; j3 += 2){
		work_area[j3] = 
			work_area[j3 + wnd_cx] = 
			work_area[j3 + 1] = 
			work_area[j3 + wnd_cx + 1] = 
			noise() % pal_size;
	}

	// average out for blur affect
    for(int l3 = wnd_cx; l3 < m_nNumPixels - wnd_cx * 3; l3++){

        work_area[l3] = ((work_area[l3 - 1] + 
							work_area[l3] + 
							work_area[l3 + 1] + 
							work_area[(l3 + wnd_cx) - 1] + 
							work_area[l3 + wnd_cx + 1] + 
							work_area[(l3 + wnd_cx + wnd_cx) - 1] + 
							work_area[l3 + wnd_cx + wnd_cx] + 
							work_area[l3 + wnd_cx + wnd_cx + 1]) / 8) - fire_height;

		if(work_area[l3] < 0){work_area[l3] = 0;} // if lower than zero, make black

		m_pBits[l3] = palette[work_area[l3]]; // set the bit
    }

	//////////////////////////////
	//							//
	//////////////////////////////

	// finally, "swap buffers"
	SetDIBitsToDevice(m_hDC,
					  m_nPlacementX,
					  m_nPlacementY,
					  wnd_cx,
					  wnd_cy,
					  0,
					  0,
					  0,
					  wnd_cy,
					  (LPVOID)m_pBits,
					  &m_bmpInfo,
					  DIB_RGB_COLORS);
}



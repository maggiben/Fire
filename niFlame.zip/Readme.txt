
This is a Flame component descended from TCustomPanel.

Written by Bevan Arps (niche@clear.net.nz) in Delphi 5. 

To see how it works, add it to the Delphi Palette, drop it on a form and set the Active property to true.

Since it is a Panel, you can drop other components on it as well. A Transparent TLabel in a contrasting colour (say Dark Blue) looks cool.

Note: This will consume ALL your CPU as flame calculation is in a separate thread. On a multi CPU machine it should only knock out one CPU not all of them. Running this on a Server is not advised!


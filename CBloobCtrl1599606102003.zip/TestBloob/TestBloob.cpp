// TestBloob.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TestBloob.h"
#include "TestBloobDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestBloobApp

BEGIN_MESSAGE_MAP(CTestBloobApp, CWinApp)
	//{{AFX_MSG_MAP(CTestBloobApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestBloobApp construction

CTestBloobApp::CTestBloobApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTestBloobApp object

CTestBloobApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTestBloobApp initialization

BOOL CTestBloobApp::InitInstance()
{
	// Standard initialization

	CTestBloobDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

//
// BloobCtrl.h : header file
// Author: Andrew Heinlein [Mouse]
// www.mouseindustries.com
// mouse@mouseindustries.com
//

#ifndef __BLOOB_CTRL_H__
#define __BLOOB_CTRL_H__

/////////////////////////////////////////////////////////////////////////////
// CBloobCtrl window

#pragma comment(lib,"Winmm.lib")

#define BLOOB_CTRL_PAL_SIZE 256
#define TIMER_ID_BLOOB_RENDER 0xCAFE

class CBloobCtrl : public CWnd
{
	friend void CALLBACK TimerProc(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime);
// Construction
public:
	CBloobCtrl();

public:
	BOOL StartBloob();
	void StopBloob(BOOL deconstruction = FALSE);
	
	BOOL IsRunning(){return m_bIsRunning;}
	int GetFPS(){return m_nFPS;}

private:
	void Render();

private:

	BOOL m_bIsRunning;

	BITMAPINFO m_bmpInfo;
	int m_nNumPixels;
	int* m_pBits;
	HDC m_hDC;
	HBITMAP m_memBmp;

	int m_nWidth;
	int m_nHeight;

	int m_nNumBloobs;
	int m_nPalette[BLOOB_CTRL_PAL_SIZE];
	int* m_pBuffer;
	int* m_nBloob;

	int m_nSize;
	int m_nBloobSize;

	int m_nFPS;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBloobCtrl)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBloobCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CBloobCtrl)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif /* __BLOOB_CTRL_H__ */

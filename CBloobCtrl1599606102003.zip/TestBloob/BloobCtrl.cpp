//
// BloobCtrl.cpp : implementation file
// Author: Andrew Heinlein [Mouse]
// www.mouseindustries.com
// mouse@mouseindustries.com
//

#include "stdafx.h"
#include "BloobCtrl.h"
#include <math.h>
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBloobCtrl

CBloobCtrl::CBloobCtrl()
{
	m_nNumBloobs = 8;
	m_pBuffer = NULL;
	m_nBloob = NULL;
	m_nSize = 0;
	m_nBloobSize = 0;
	m_nWidth = 0;
	m_nHeight = 0;
	m_nNumPixels = 0;
	m_pBits = NULL;
	m_hDC = NULL;
	m_memBmp = NULL;
	m_nFPS = 0;
}

CBloobCtrl::~CBloobCtrl()
{
	StopBloob(TRUE);
}

BEGIN_MESSAGE_MAP(CBloobCtrl, CWnd)
	//{{AFX_MSG_MAP(CBloobCtrl)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CBloobCtrl message handlers

BOOL CBloobCtrl::PreCreateWindow(CREATESTRUCT& cs) 
{
	if(!CWnd::PreCreateWindow(cs)){
		return FALSE;}

	cs.style &= ~WS_BORDER; // take off 1 pixel black border
	cs.style |= WS_VISIBLE | WS_TABSTOP | WS_CHILD;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_GLOBALCLASS|CS_PARENTDC|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

//
// start up bloobs
//
BOOL CBloobCtrl::StartBloob(){
	CRect rc;
	GetClientRect(rc);
	
	// init vars
	m_nWidth = rc.Width();
	m_nHeight = rc.Height();
	m_nSize = m_nWidth*m_nHeight;
	m_nBloobSize = m_nHeight/6*3;
	m_pBuffer = new int[m_nSize];
	m_nBloob = new int[m_nBloobSize * m_nBloobSize];

	memset(m_pBuffer,0,m_nSize*sizeof(int));
	memset(m_nBloob,0,(m_nBloobSize * m_nBloobSize)*sizeof(int));

	// create palette
	for(int i = 0; i < 64; i++)
		m_nPalette[i] = 0;
	for(i = 0; i < 32; i++)
		m_nPalette[64 + i] = ((i * 6) << 16) | (i * 6);
	for(i = 0; i < 32; i++)
		m_nPalette[96 + i] = ((192 + i * 2) << 16) | ((i * 8) << 8) | (192 + i * 2);
	for(i = 128; i < BLOOB_CTRL_PAL_SIZE; i++)
		m_nPalette[i] = RGB(255,255,255);

	// init bloobs
	for(int y = 0; y < m_nBloobSize; y++){
		for(int x = 0; x < m_nBloobSize; x++){
			float k = (float)(1 - hypot(x - m_nBloobSize / 2, y - m_nBloobSize / 2) * 2 / m_nBloobSize);
			if (k < 0) k = 0;
			int c = (int)(255.0f * k * k);
			m_nBloob[x + y * m_nBloobSize] = c;
		}
	}

	// create memory bitmap
	DWORD sizeOfBits = (((m_nWidth * 32 + 31) & ~31) >> 3) * m_nHeight;
	m_nNumPixels = sizeOfBits / sizeof(RGBQUAD);

	memset(&m_bmpInfo,0,sizeof(m_bmpInfo));
	m_bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	m_bmpInfo.bmiHeader.biWidth = m_nWidth;
	m_bmpInfo.bmiHeader.biHeight = m_nHeight; // make negative for "right side up" bitmap
	m_bmpInfo.bmiHeader.biSizeImage = sizeOfBits;
	m_bmpInfo.bmiHeader.biPlanes = 1;
	m_bmpInfo.bmiHeader.biBitCount = 32;

	m_hDC = ::GetWindowDC(m_hWnd);
	m_memBmp = CreateDIBSection(m_hDC, &m_bmpInfo, DIB_RGB_COLORS, (void**)&m_pBits, NULL, 0);
	memset(m_pBits,0,sizeOfBits);

	m_bIsRunning = TRUE;
	SetTimer(TIMER_ID_BLOOB_RENDER,1,NULL);

	return TRUE;
}

//
// shut down bloobs
//
void CBloobCtrl::StopBloob(BOOL deconstruction/* = FALSE*/){
	m_bIsRunning = FALSE;
	if(!deconstruction)
		KillTimer(TIMER_ID_BLOOB_RENDER);
	if(m_pBuffer)
		delete m_pBuffer;
	if(m_nBloob)
		delete m_nBloob;
	m_pBuffer = NULL;
	m_nBloob = NULL;
	m_nSize = 0;
	m_nBloobSize = 0;
	m_nHeight = 0;
	m_nWidth = 0;
	m_nNumPixels = 0;
	m_nFPS = 0;
	m_pBits = NULL;
	if(m_hDC)
		::ReleaseDC(m_hWnd, m_hDC);
	m_hDC = NULL;
	if(m_memBmp)
		::DeleteObject(m_memBmp);
	m_memBmp = NULL;
}

//
// render bloobs
//
void CBloobCtrl::Render(){
	if(!m_bIsRunning){ return; }

	// FPS
	DWORD gtc = GetTickCount();
	static DWORD nextUpdate = 0;
	static int count = 0;
	if(nextUpdate < gtc){
		nextUpdate = gtc+1000;
		m_nFPS = count;
		count = 0;
	}else{
		++count;
	}

	memset(m_pBuffer,0,m_nSize*sizeof(int));

	for(float i = 0; i < m_nNumBloobs; i++){
		int x = (int)(m_nWidth / 2  - m_nBloobSize / 2 + m_nHeight / 4 * cos(timeGetTime() / (800 - i * 50) + i));
		int y = (int)(m_nHeight / 2 - m_nBloobSize / 2 + m_nHeight / 4 * sin(timeGetTime() / (600 + i * 50) - i));
		int* dst = m_pBuffer + x + y * m_nWidth;
		int* src = m_nBloob;
		int wp = m_nWidth - m_nBloobSize;
		for(int v = 0; v < m_nBloobSize; v++, dst += wp){
			for(int u = 0; u < m_nBloobSize; u++, dst++, src++){
				int c = *dst + *src;
				*dst = (c > 255) ? 255 : c;
			}
		}
	}

	// Dags att rita bild p� sk�rm. eftersom vi fakar 8bits s� g�r vi s� h�r
	for(int e = 0; e < m_nSize; e++)
		m_pBits[e] = m_nPalette[m_pBuffer[e]];

	SetDIBitsToDevice(m_hDC,
					  0,
					  0,
					  m_nWidth,
					  m_nHeight,
					  0,
					  0,
					  0,
					  m_nHeight,
					  (LPVOID)m_pBits,
					  &m_bmpInfo,
					  DIB_RGB_COLORS);
}

void CBloobCtrl::OnTimer(UINT nIDEvent){
	if(nIDEvent==TIMER_ID_BLOOB_RENDER)
		Render();
	CWnd::OnTimer(nIDEvent);
}

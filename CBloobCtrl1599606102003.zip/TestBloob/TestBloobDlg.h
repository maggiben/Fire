// TestBloobDlg.h : header file
//

#if !defined(AFX_TESTBLOOBDLG_H__98804507_E3E1_4B4B_ADBB_32EAEE579B29__INCLUDED_)
#define AFX_TESTBLOOBDLG_H__98804507_E3E1_4B4B_ADBB_32EAEE579B29__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestBloobDlg dialog

#include "BloobCtrl.h"

class CTestBloobDlg : public CDialog
{
// Construction
public:
	CTestBloobDlg(CWnd* pParent = NULL);	// standard constructor

	CBloobCtrl m_BloobCtrl;

// Dialog Data
	//{{AFX_DATA(CTestBloobDlg)
	enum { IDD = IDD_TESTBLOOB_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestBloobDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestBloobDlg)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	afx_msg void OnCheckLargeView();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTBLOOBDLG_H__98804507_E3E1_4B4B_ADBB_32EAEE579B29__INCLUDED_)

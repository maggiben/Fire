// TestBloobDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestBloob.h"
#include "TestBloobDlg.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestBloobDlg dialog

CTestBloobDlg::CTestBloobDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestBloobDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestBloobDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestBloobDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestBloobDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestBloobDlg, CDialog)
	//{{AFX_MSG_MAP(CTestBloobDlg)
	ON_BN_CLICKED(IDC_CHECK_LARGE_VIEW, OnCheckLargeView)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestBloobDlg message handlers

BOOL CTestBloobDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	CRect rc;
	GetDlgItem(IDC_BLOOB_VIEW)->GetWindowRect(rc);
	GetDlgItem(IDC_BLOOB_VIEW)->DestroyWindow();
	ScreenToClient(rc);

	m_BloobCtrl.Create(NULL,"bloob_view",0,rc,this,IDC_BLOOB_VIEW);
	m_BloobCtrl.StartBloob();

	SetTimer(12345,1000,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

//
//
//
void CTestBloobDlg::OnCancel(){
	m_BloobCtrl.StopBloob();
	CDialog::OnCancel();
}

void CTestBloobDlg::OnTimer(UINT nIDEvent){

	CString str;
	str.Format(_T("CBloobCtrl()->FPS: %i"), m_BloobCtrl.GetFPS());
	SetWindowText(str);
	
	CDialog::OnTimer(nIDEvent);
}

//
//
//
void CTestBloobDlg::OnCheckLargeView(){
	BOOL bLarge = IsDlgButtonChecked(IDC_CHECK_LARGE_VIEW);
	m_BloobCtrl.StopBloob();

	// IDC_STATIC_FRAME
	if(bLarge){
		SetWindowPos(NULL,0,0,550,400,SWP_NOMOVE);
		GetDlgItem(IDC_STATIC_FRAME)->SetWindowPos(NULL,0,0,380,370,SWP_NOMOVE);
		m_BloobCtrl.SetWindowPos(NULL,0,0,365,347,SWP_NOMOVE);
	}else{
		SetWindowPos(NULL,0,0,400,250,SWP_NOMOVE);
		GetDlgItem(IDC_STATIC_FRAME)->SetWindowPos(NULL,0,0,227,220,SWP_NOMOVE);
		m_BloobCtrl.SetWindowPos(NULL,0,0,210,197,SWP_NOMOVE);
	}


	m_BloobCtrl.StartBloob();
}

void CTestBloobDlg::OnAbout() 
{
	m_BloobCtrl.StopBloob();
	m_BloobCtrl.ShowWindow(SW_HIDE);

	CAboutDlg dlg(this);
	dlg.DoModal();

	m_BloobCtrl.ShowWindow(SW_SHOW);
	m_BloobCtrl.StartBloob();
}

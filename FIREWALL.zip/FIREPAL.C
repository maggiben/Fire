#include <stdio.h>
main() {
    int i,j;
    printf("FirePal  ");

    printf("db  ");
    for(i=0;i<79;i++) {
          printf("%d,%d,%d,",0,0,0);
          }
    printf("0,0,0\n");

    printf("db  ");
    for(i=0;i<49;i++) {
          printf("%d,%d,%d,",i+15,0,0);
          }
    printf("63,0,0\n");

    printf("db  ");
    for(i=0;i<64;i++) {
          printf("%d,%d,%d,",63,i,0);
          }
    printf("63,63,0\n");

    printf("db  ");
    for(i=0;i<64;i++) {
          printf("%d,%d,%d,",63,63,i);
          }
    printf("63,63,63\n");


    }



      

//---------------------------------------------------------------------------
#ifndef GameComponentH
#define GameComponentH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>

//---------------------------------------------------------------------------
class TGameComponent : public TComponent
{
private:


protected:
    float FXPos;
    float FYPos;
    float FZPos;

    float FXScl;
    float FYScl;
    float FZScl;



public:
    int Register(TComponent* Owner);
    
    void __fastcall SetXPos(float value);
    void __fastcall SetYPos(float value);
    void __fastcall SetZPos(float value);

    void __fastcall SetXScale(float value);
    void __fastcall SetYScale(float value);
    void __fastcall SetZScale(float value);

    float __fastcall GetXPos();
    float __fastcall GetYPos();
    float __fastcall GetZPos();

    float __fastcall GetXScale();
    float __fastcall GetYScale();
    float __fastcall GetZScale();
    
    __fastcall TGameComponent(TComponent* Owner);

    //Interface for Game Component
    virtual void Move(float Time) = 0;
    virtual void Paint(void);


    //Registers component with opengl form

__published:
    __property float XPos  = { read = GetXPos, write = SetXPos };
    __property float YPos  = { read = GetYPos, write = SetYPos };
    __property float ZPos  = { read = GetZPos, write = SetZPos };

    __property float XScale  = { read = GetXScale, write = SetXScale };
    __property float YScale  = { read = GetYScale, write = SetYScale };
    __property float ZScale  = { read = GetZScale, write = SetZScale };
};
//---------------------------------------------------------------------------
#endif

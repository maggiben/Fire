/****************************************************************************
Name: OGLForm.cpp
Desc: OpenGL Form
Auth: Dallas Nutsch
Rev : 1


****************************************************************************/

#include <vcl.h>
#pragma hdrstop


#include <float.h>
#include "OGLForm.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "GameComponent"
#pragma link "FlameComponent"

#pragma link "FlameComponent"
#pragma link "GameComponent"
#pragma link "FlameComponent"
#pragma link "GameComponent"
#pragma resource "*.dfm"


TOpenGLForm *OpenGLForm;
//Type for window procedure pointer
typedef int (__stdcall * MyWNDPROC)(void);
/**************************************************
class:                    func:
desc : Global WNDPROC To Override WM_ERASEBKGND
**************************************************/
LRESULT pascal TOpenGLFormPROC (HWND wnd,UINT msg, WPARAM wParam, LPARAM lParam)
{
   //Get
   MyWNDPROC oldproc = (MyWNDPROC)GetWindowLong(wnd,GWL_USERDATA);
   switch(msg)
   {
     case WM_ERASEBKGND: return -1;
      default:
      break;
   };
   return CallWindowProc(oldproc,wnd,msg,wParam,lParam);
}


void __fastcall TOpenGLForm::TOpenGLFormChildCallback  (TComponent* Child)
{
  if (Child->InheritsFrom(__classid(TGameComponent)) )
  {
    //Game component, register with form
    TGameComponent * c = (TGameComponent *)Child;
    c->Register(Child->Owner);
  }
}

/**************************************************
class:                    func:
desc :
**************************************************/
__fastcall TOpenGLForm::TOpenGLForm(TComponent* Owner) : TForm(Owner)
{
    Sleep(1);
    GetChildren((TGetChildProc) &TOpenGLFormChildCallback,this);
}
/**************************************************
class:                    func:
desc : Subclasses form window
**************************************************/
void TOpenGLForm::SubClassForm()
{
     MyWNDPROC proc = (MyWNDPROC)GetWindowLong (Handle,GWL_WNDPROC);
     SetWindowLong(Handle,GWL_USERDATA,(DWORD) proc);
     SetWindowLong(Handle,GWL_WNDPROC,(DWORD) TOpenGLFormPROC);

}
/**************************************************
class:                    func:
desc :  Unsubclasses form window
**************************************************/
void TOpenGLForm::UnSubclassForm()
{
   WNDPROC proc = (WNDPROC)GetWindowLong (Handle,GWL_WNDPROC);
   SetWindowLong(Handle,GWL_WNDPROC,(DWORD) proc);
}
/**************************************************
class:                    func:
desc : Initializes OpenGLf
**************************************************/
int TOpenGLForm::InitGL()
{
  m_DC = ::GetDC(Handle );
  HGLRC hg = wglGetCurrentContext();
  if (hg!=NULL) wglDeleteContext(hg);

  PIXELFORMATDESCRIPTOR pfd = {
    sizeof(PIXELFORMATDESCRIPTOR),    // size of this pfd
    1,                                // version number
    PFD_DRAW_TO_WINDOW |              // support window
    PFD_SUPPORT_OPENGL |              // support OpenGL
    PFD_DOUBLEBUFFER,                 // double buffered
    PFD_TYPE_RGBA,                    // RGBA type
    16,                               // color depth
    0, 0, 0, 0, 0, 0,                 // color bits ignored
    0,                                // no alpha buffer
    0,                                // shift bit ignored
    0,                                // no accumulation buffer
    0, 0, 0, 0,                       // accum bits ignored
    0,                               // z-buffer
    0,                                // no stencil buffer
    0,                                // no auxiliary buffer
    PFD_MAIN_PLANE,                   // main layer
    0,                                // reserved
    0, 0, 0                           // layer masks ignored
	};

    int  iPixelFormat;

  iPixelFormat = ChoosePixelFormat(m_DC, &pfd);
  SetPixelFormat(m_DC, iPixelFormat, &pfd);

  m_Context = wglCreateContext(m_DC);
  wglMakeCurrent(m_DC, m_Context);

  glDisable(GL_LIGHTING);
  glEnable(GL_DEPTH_TEST);
  glDisable(GL_CULL_FACE);

  ShowWindow(Handle,SW_SHOW);
  UpdateWindow(Handle);

  UpdateGLViewport();
  return TRUE;
}
/**************************************************
class:                    func:
desc :
**************************************************/
int TOpenGLForm::DeInitGL()
{
    //Delete OpenGL Rendering Context

    HGLRC hg = wglGetCurrentContext();
    if (hg!=NULL) wglDeleteContext(hg);

    //Get rid of window DC
    ::ReleaseDC(Handle,m_DC);

    return TRUE;
}
/**************************************************
class:                    func:
desc : Updates OpenGL Viewport as window is resized
**************************************************/
void TOpenGLForm::UpdateGLViewport()
{
    //Update OpenGL Viewport

    glViewport (0,0, ClientWidth, ClientHeight);

    //Setup matrices

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)ClientWidth/ClientHeight, 30, 5000.0f);
    glTranslatef(0,-20,-105);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    //Call updatewindow here to draw while resizing

    UpdateWindow(Handle);
}
/**************************************************
class:                    func:
desc : When form is idle, we repaint it
**************************************************/
void __fastcall TOpenGLForm::FormIdleHandler(TObject *Sender, bool &Done)
{
    MoveObjects();
    FormPaint(Sender);
    Done = false;
}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TOpenGLForm::FormResize(TObject *Sender)
{
      //Since our resolution has changed, resize OpenGL Viewport
      UpdateGLViewport();
}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TOpenGLForm::FormDestroy(TObject *Sender)
{
   //Restore window procedure
   UnSubclassForm();

   //Release OpenGL Context
   DeInitGL();

}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TOpenGLForm::FormCreate(TObject *Sender)
{
     //To be on the safe side, disable floating point exceptions
    _control87(MCW_EM, MCW_EM);

    //Hook the window message handerl
    SubClassForm();

    //Set our idle handler
    Application->OnIdle = FormIdleHandler;

    //Initialize OpenGL
    InitGL();

    //Fixup style

    DWORD style = GetWindowLong(Handle,GWL_STYLE);
    style|=  WS_CLIPCHILDREN  | WS_CLIPCHILDREN;
    SetWindowLong(Handle,GWL_STYLE,style);

    style = GetWindowLong(Handle,GWL_EXSTYLE);
    style|=  WS_EX_TOPMOST;
    SetWindowLong(Handle,GWL_EXSTYLE,style);
    SetWindowPos(Handle,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
    
}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TOpenGLForm::FormPaint(TObject *Sender)
{
static float rot = 0;
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glRotatef(rot,0,1,0);
    rot+=1;


     //TODO: Call component Render functions here
     std::vector<TGameComponent *>::iterator GameComIterator;
     for (GameComIterator=m_Components.begin();GameComIterator<m_Components.end() ;GameComIterator++)
     {
          (*GameComIterator)->Paint();
     }
    glFlush();
    SwapBuffers(m_DC);

    
    glPopMatrix();

}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TOpenGLForm::MoveObjects()
{
    //TODO: Call component Move functions here
     std::vector<TGameComponent *>::iterator GameComIterator;
     for (GameComIterator=m_Components.begin();GameComIterator<m_Components.end() ;GameComIterator++)
     {
          (*GameComIterator)->Move(1.0f);
     }


}

/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TOpenGLForm::SetFieldOfVision(float value)
{
     FieldOfVision = value;
}
/**************************************************
class:                    func:
desc :
**************************************************/
float __fastcall TOpenGLForm::GetFieldOfVision()
{
     return FieldOfVision;
}


TOpenGLForm::AddGameComponent(TGameComponent * com)
{

 m_Components.push_back(com);
 return TRUE;
}

void __fastcall TOpenGLForm::FormCanResize(TObject *Sender, int &NewWidth,
      int &NewHeight, bool &Resize)
{
      Resize=TRUE;
      if (NewWidth>800)
      {                 
        NewWidth=800;
      }
      if (NewHeight>600)
      {
        NewHeight=600;
      }
}
//---------------------------------------------------------------------------


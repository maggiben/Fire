//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("Flame.res");
USEFORM("OGLForm.cpp", OpenGLForm);
USEUNIT("GameComponent.cpp");
USEUNIT("FlameComponent.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TOpenGLForm), &OpenGLForm);
         Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------

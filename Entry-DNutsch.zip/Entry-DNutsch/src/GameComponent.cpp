/****************************************************************************
Name: GameComponent.cpp
Desc: OpenGL Form
Auth: Dallas Nutsch
Rev : 1

Base class for game components

****************************************************************************/

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "OGLForm.h"


//---------------------------------------------------------------------------
__fastcall TGameComponent::TGameComponent(TComponent* Owner)
    : TComponent(Owner)
{
    FXPos = 0.0f;
    FYPos = 0.0f;
    FZPos = 0.0f;
    FXScl = 1.0f;
    FYScl = 1.0f;
    FZScl = 1.0f;
 }

/**************************************************
class:                    func:
desc : Registers this object with form, components shouldn't be deconstructed until form is destructor
**************************************************/
int TGameComponent::Register(TComponent* Owner)
{
    if (Owner==NULL || !Owner->InheritsFrom( __classid(TOpenGLForm))) return FALSE;

    TOpenGLForm * form = (TOpenGLForm*) Owner;
    form->AddGameComponent(this);
    return TRUE;
}

/**************************************************
class:                    func:
desc :
**************************************************/
void TGameComponent::Paint()
{
    glTranslatef(FXPos,FYPos,FZPos);
    glScalef(FXScl,FYScl,FZScl); 
}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TGameComponent::SetXPos(float value)
{
    FXPos = value;
}
void __fastcall TGameComponent::SetYPos(float value)
{
    FYPos = value;
}
void __fastcall TGameComponent::SetZPos(float value)
{
    FZPos = value;
}
/**************************************************
class:                    func:
desc :
**************************************************/
float __fastcall TGameComponent::GetXPos()
{
    return FXPos;
}
float __fastcall TGameComponent::GetYPos()
{
    return FYPos;
}
float __fastcall TGameComponent::GetZPos()
{
    return FZPos;
}
/**************************************************
class:                    func:
desc :
**************************************************/
float __fastcall TGameComponent::GetXScale()
{
  return FXScl;
}
float __fastcall TGameComponent::GetYScale()
{
  return FYScl;
}
float __fastcall TGameComponent::GetZScale()
{
  return FZScl;
}
/**************************************************
class:                    func:
desc :
**************************************************/
void __fastcall TGameComponent::SetXScale(float value)
{
    FXScl = value;
}
void __fastcall TGameComponent::SetYScale(float value)
{
    FYScl = value;
}
void __fastcall TGameComponent::SetZScale(float value)
{
    FZScl = value;
}



//---------------------------------------------------------------------------
#ifndef FlameComponentH
#define FlameComponentH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>


//---------------------------------------------------------------------------

#define DEF_ASHES 64

class PACKAGE TFlameComponent : public TGameComponent
{
private:
    int FNumAshes;
    float FAshFreq;
    bool FUseAshes;
    void __fastcall SetNumAshes(int value);
    int __fastcall GetNumAshes();
    void __fastcall SetAshFreq(float value);
    float __fastcall GetAshFreq();
    void __fastcall SetUseAshes(bool value);
    bool __fastcall GetUseAshes();
protected:

    static unsigned int m_Textures[8];
    static byte flames[10][66][64*4];
    static int count;
    int num;
    float * m_Ashes;
    float Life;

public:
    float AddRotation;
    __fastcall TFlameComponent(TComponent* Owner);

    //Abstract methods from TGameComponent

    void Move(float Time);
    void Paint(void);
    __fastcall virtual ~TFlameComponent();

    void SpawnEmber (float x, float y, float z);


__published:
    __property int NumAshes  = { read = GetNumAshes, write = SetNumAshes };
    __property float AshFreq  = { read = GetAshFreq, write = SetAshFreq };
    __property bool UseAshes  = { read = GetUseAshes, write = SetUseAshes };
};
//---------------------------------------------------------------------------
#endif
 
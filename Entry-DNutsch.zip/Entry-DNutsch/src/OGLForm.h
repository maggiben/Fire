/****************************************************************************
Name: OGLForm.h
Desc: OpenGL Form
Auth: Dallas Nutsch
Rev : 1


****************************************************************************/
#ifndef OGLFormH
#define OGLFormH

//---------------------------------------------------------------------------


#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "GameComponent.h"
#include "FlameComponent.h"





   //OpenGL Headers
#include <gl/gl.h>
#include <gl/glu.h>

//STL Vector class
#include <vector>
//---------------------------------------------------------------------------

class TOpenGLForm : public TForm
{
public:
__published:	// IDE-managed Components
    TFlameComponent *FlameComponent1;
    TFlameComponent *FlameComponent2;
    TFlameComponent *FlameComponent3;
    TFlameComponent *FlameComponent4;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;

    void __fastcall FormIdleHandler(TObject *Sender, bool &Done);   
    void __fastcall FormResize(TObject *Sender);
    void __fastcall FormDestroy(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall FormPaint(TObject *Sender);
    void __fastcall FormCanResize(TObject *Sender, int &NewWidth,
          int &NewHeight, bool &Resize);

__published:
 __property float FieldOfVision  = { read = GetFieldOfVision, write = SetFieldOfVision, default=45};

private:	// User declarations

   //Subclassing Functions

    void SubClassForm();
    void UnSubclassForm();

    //Init functions

    int InitGL();


    //Deinit functions

    int DeInitGL();


    //Members

    HDC m_DC;
    HGLRC m_Context;
    void __fastcall SetFieldOfVision(float value);
    float __fastcall GetFieldOfVision();

    std::vector<TGameComponent *> m_Components;



protected:

    //General Functions
    void UpdateGLViewport();
    void __fastcall MoveObjects();


public:		// User declarations

    void __fastcall TOpenGLForm::TOpenGLFormChildCallback  (TComponent* Child)   ;
 
    __fastcall TOpenGLForm(TComponent* Owner);
    AddGameComponent(TGameComponent * com);
};
//---------------------------------------------------------------------------
extern PACKAGE TOpenGLForm *OpenGLForm;
//---------------------------------------------------------------------------
#endif

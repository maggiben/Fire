/****************************************************************************
Name: Flame Component.cpp
Desc: OpenGL Form
Auth: Dallas Nutsch
Rev : 1

Flame Component

****************************************************************************/


#include <vcl.h>
#pragma hdrstop

#include "OGLForm.h"


#include <math.h>
#pragma package(smart_init)
//---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//


//Coords for flames

const float g_FlameVerts[8][3] =
{
    {-0.875,0    ,0},
    {0.875 ,0    ,0},
    {1     ,5    ,0},
    {-1    ,5    ,0},
    {-0.875,0    ,0},
    {0     ,0.375,0},
    {0.875 ,0    ,0},
    {0     ,-0.31,0}
};

const float g_FlameCoords[8][2] =
{
    {0,0.2 },
    {1,0.05},
    {1,0.99},
    {0,0.99},
    {0,0.2 },
    {0,0   },
    {1,0.2 },
    {1,0   }
};

#define FLAME_DEF_SCALE 16.0










//Static members of TFlameComponent
int TFlameComponent::count = 0;
unsigned int TFlameComponent::m_Textures[8];
byte TFlameComponent::flames[10][66][64*4];

static inline void ValidCtrCheck(TFlameComponent *)
{
    new TFlameComponent(NULL);
}
//---------------------------------------------------------------------------
__fastcall TFlameComponent::TFlameComponent(TComponent* Owner)
    : TGameComponent(Owner)
{
    //Set a rotation value so not all fires look the same
    AddRotation = (float)rand()/RAND_MAX;

    Life=0.0f;
    FAshFreq=1.0;
    FUseAshes=true;

    FXScl = FLAME_DEF_SCALE;
    FYScl = FLAME_DEF_SCALE;
    FZScl = FLAME_DEF_SCALE;

    
    //Zero ashes
    m_Ashes=NULL;
    FNumAshes = DEF_ASHES;
    if ( FNumAshes>0)
    {
        m_Ashes=new float[FNumAshes*4];
        for (int i =0; i<FNumAshes*4;i+=4)
        {
            m_Ashes[i+3]=-1.0f;
        }  
    }

    //Zero flame stuff

    num = TFlameComponent::count;
    TFlameComponent::count++;

    Move(1.0);

    if (num==0)
    {
        FillMemory(&(TFlameComponent::flames[0][0][0]),sizeof(char)*8*66*64*4,1);

        //Create textures
        glGenTextures(6,TFlameComponent::m_Textures);
        for (int x= 0; x < 6; x++ )
        {
            glBindTexture(GL_TEXTURE_2D,TFlameComponent::m_Textures[x]);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
            glTexImage2D(GL_TEXTURE_2D,0,4,64,64,0,GL_RGBA,GL_UNSIGNED_BYTE,&(TFlameComponent::flames[x+1][2][0]));
        }
    }

}
//---------------------------------------------------------------------------
namespace Flamecomponent
{
    void __fastcall PACKAGE Register()
    {
         TComponentClass classes[1] = {__classid(TFlameComponent)};
         RegisterComponents("Game Components", classes, 0);
    }
}

//Implementation of  TGameComponent interface

/**************************************************
class:                    func:
desc :
**************************************************/



void TFlameComponent::Move(float Time)
{
   //Flame is stationary, movement is based on per frame

   Life+=Time;
   float one_over = 1/FAshFreq;

   //If an ash needs to be spawned, do that
   if (Life > one_over && FAshFreq>0.0 && FUseAshes==true)
   {
     while (Life>one_over)
     {
       SpawnEmber(-0.5f+(float)rand()*1/RAND_MAX,
                  0.625+(float)rand()*0.625/RAND_MAX,
                  -0.5f+(float)rand()*1/RAND_MAX);
       Life-=one_over;
     }
   }

   //Build textures
   //TODO:  Assembly here

    int i,j,k;
    int col =0;


    //The first world fire is responsible for building the global fire texture maps
    if (num==0)
    {
        //Build random base for flames
        for ( i = 0; i < 10; i++)
          for ( j = 0; j < 1; j++)
            for ( k = 0; k < 60*4; k+=4)
            {
                flames[i][j][k+3] = col;
                flames[i][j+1][k+3] = flames[i][j][k+3];

                if (rand()*5/RAND_MAX ==0) col = (rand()*2/RAND_MAX*255);
            }

        //Do ye olde flame code except volumetric
        for ( i = 1; i < 9;i++)
          for ( j = 1; j < 66; j++)
            for ( k = 1*4; k < 63*4; k+=4)
            {
                TFlameComponent::flames[i][j][k+3]=
                ((int)TFlameComponent::flames[i+1][j-1][k+3+4]+
                TFlameComponent::flames[i-1][j-1][k+3-4]+
                TFlameComponent::flames[i+1 ][j-1][k-4+3]+
                TFlameComponent::flames[i-1 ][j-1][k+3+4]+
                TFlameComponent::flames[i][j-1][k+3+4]+
                TFlameComponent::flames[i][j-1][k+3-4]+
                TFlameComponent::flames[i+1 ][j-1][k+3]+
                TFlameComponent::flames[i-1 ][j-1][k+3]
                )>>3;

                if (TFlameComponent::flames[i][j][k+3])TFlameComponent::flames[i][j][k+3]--;

                TFlameComponent::flames[i][j][k]=255;
                TFlameComponent::flames[i][j][k+1]=255-(128-TFlameComponent::flames[i][j][k+3]/2);
                TFlameComponent::flames[i][j][k+2]=TFlameComponent::flames[i][j][k+3];
            }


        //Create Textures
        for ( i = 1; i < 7;i++)
        {
            glBindTexture(GL_TEXTURE_2D,TFlameComponent::m_Textures[i-1]);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
            glTexImage2D(GL_TEXTURE_2D,0,4,64,64,0,GL_RGBA,GL_UNSIGNED_BYTE,&(TFlameComponent::flames[i][2][0]));
        }
    }
}

/**************************************************
class:                    func:
desc :
**************************************************/
void TFlameComponent::Paint(void)
{

    //Static variable for fire rotation
    static float rot = 0.0f;
    int i,j;
    //Push matrix

    //Rotation adds to flame effect
    rot +=1.0f;

    glPushMatrix();
    //Call base class to concat a translation and scale
    TGameComponent::Paint();
    glPushMatrix();
    glRotatef(rot+AddRotation,0,1,0);

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE);
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glDepthMask(0);

    for ( i = 1; i < 7;i++)
    {
        glBindTexture(GL_TEXTURE_2D,TFlameComponent::m_Textures[i-1]);

        glPushMatrix();
        glRotatef(i*40,0,1,0);
          glBegin(GL_QUADS);
            glColor4f(1,1,1,1);

            for (j=0;j<4;j++)
            {
              glTexCoord2fv(g_FlameCoords[j]);
              glVertex3fv  (g_FlameVerts[j]);
            }
          glEnd();
        glPopMatrix();


        glPushMatrix();
        glRotatef(-i*40+20,0,1,0);
          glBegin(GL_QUADS);
            for (j=0;j<4;j++)
            {
              glTexCoord2fv(g_FlameCoords[j]);
              glVertex3fv  (g_FlameVerts [j]);
            }
          glEnd();
        glPopMatrix();
        glPopMatrix();

        glPushMatrix();
        glPushMatrix();
        glRotatef(i*40,0,1,0);
          glBegin(GL_QUADS);
            glColor4f(1,1,1,1);

            for (j=4;j<8;j++)
            {
              glTexCoord2fv(g_FlameCoords[j]);
              glVertex3fv  (g_FlameVerts[j]);
            }
          glEnd();
        glPopMatrix();


        glPushMatrix();
        glRotatef(-i*40+20,0,1,0);
          glBegin(GL_QUADS);
            for (j=4;j<8;j++)
            {
              glTexCoord2fv(g_FlameCoords[j]);
              glVertex3fv  (g_FlameVerts [j]);
            }
          glEnd();
        glPopMatrix();


    }

  glPopMatrix();    
    //Now render the ashes
  glRotatef(rot+AddRotation,0,1,0);

  glDepthMask(1);
  glPointSize(2.0);
  glDisable(GL_POINT_SMOOTH);
  glDisable(GL_TEXTURE_2D);
  glEnable(GL_DEPTH_TEST);

  glBegin (GL_POINTS);


  for (i = 0;i < FNumAshes*4;i+=4)
  {
      static float sinstatic=0;
      sinstatic+=0.001;
      if (m_Ashes[i+3] > 0)
      {
          m_Ashes[i+1]+=0.0625;
          m_Ashes[i+3]=m_Ashes[i+1]/5;
          glColor4f(1,0.5+ m_Ashes[i+3]/2,m_Ashes[i+3],1.0-m_Ashes[i+3]);
          glVertex3f(m_Ashes[i]+0.125*sin(sinstatic+(i+AddRotation)),m_Ashes[i+1],m_Ashes[i+2]);
          if (m_Ashes[i+1]>5.0) m_Ashes[i+3]=-1;
      }
  }
  glEnd();

  glPopMatrix();   
}


void __fastcall TFlameComponent::SetNumAshes(int value)
{
    FNumAshes = value;
    if (m_Ashes!=NULL) delete [] m_Ashes;
    if ( FNumAshes>0)
    {
      m_Ashes=new float[FNumAshes*4];
    }
}

int __fastcall TFlameComponent::GetNumAshes()
{
    return FNumAshes;
}


void __fastcall TFlameComponent::SetAshFreq(float value)
{
    FAshFreq = value;
}

float __fastcall TFlameComponent::GetAshFreq()
{
    return FAshFreq;
}


__fastcall TFlameComponent::~TFlameComponent()
{
    if (m_Ashes!=NULL) delete [] m_Ashes;
    TFlameComponent::count--;

    //Last flame destroyed is responsible for releasing texture handles
    if (TFlameComponent::count==0)
    {
        glGenTextures(6,TFlameComponent::m_Textures);
    }

}


void TFlameComponent::SpawnEmber (float x, float y, float z)
{
    int c;
    for ( c = 0;c<FNumAshes*4;c+=4)
    {
      if (m_Ashes[c+3]<=0) break;
    }
    if (c <FNumAshes*4)
    {
        m_Ashes[c+0]=x;
        m_Ashes[c+1]=y;
        m_Ashes[c+2]=z;
        m_Ashes[c+3]=0.1;
    }

}

void __fastcall TFlameComponent::SetUseAshes(bool value)
{
    FUseAshes = value;
}

bool __fastcall TFlameComponent::GetUseAshes()
{
    return FUseAshes;
}

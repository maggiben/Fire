// Eric Anderson
// Fire Effect
// 5/3/00

#include <iostream.h>
#include <conio.h>
#include <iomanip.h>
#include <dos.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <fstream.h>

unsigned char Pall2[256][3];   									    // storage for palette values
unsigned char far* vga = (unsigned char *) MK_FP(0xA000, 0); // pointer to video card
unsigned char far* buffer;      // for our backbuffer
unsigned char far* fire_buffer; // for the fire

#include "grafix.h"

// varoius functions for pixels in buffer & fire_buffer
inline PutPixelBuffer(int x, int y, unsigned char Col) { memset(buffer+x+(y*320),Col,1); }
inline int GetPixelBuffer(register int x,register int y) {return buffer[(y<<8)+(y<<6)+x];}
inline PutPixelFireBuffer(int x, int y, unsigned char Col) { fire_buffer[(y<<8)+(y<<6)+x]=Col; }
inline int GetPixelFireBuffer(register int x,register int y) {return fire_buffer[(y<<8)+(y<<6)+x];}

// copies the memory of the backbuffer into the video memory
void DisplayBuffer()
{
	_fmemcpy( vga, buffer, 64000 );
}

// moves the fire bufffer data into the buffer data
void MoveIntoBuffer()
{
	_fmemcpy( buffer, fire_buffer, 64000 );
}

// clears out the buffer
void ClearBuffer()
{
	_fmemset( buffer, 0, 64000 );
}

// clears out the fire buffer
void ClearFireBuffer()
{
	_fmemset( fire_buffer, 0, 64000 );
}

// sets up the firepalette
void FirePalette();
// does the fire
void Fire();

int main()
{
	// checks to see if enough memory is available, if not
	// it quits
	if ((buffer=(unsigned char*)malloc(64000))==NULL)
	{
		cout << "not enough memory for double buffer";
		getch();
		exit(1);
	}
	if ((fire_buffer=(unsigned char*)malloc(64000))==NULL)
	{
		cout << "not enough memory for fire buffer";
		getch();
		exit(1);
	}
   randomize();
	// Sets our video mode to 320x200x256
	SetVideoMode();
	// Clears our buffer - there might be data in there
	ClearBuffer();
	// Sets up our palette
	FirePalette();
	//does the fire
	Fire();
	return 0;
}

void Fire()
{
	// clears out the fire buffer
	ClearFireBuffer();
	// loops while you dont hit a key
	while ( !kbhit() )
	{
		// shows the buffer
		DisplayBuffer();
		for ( int x = 1; x < 315; x+=rand()%10 )
		{
			// draws coals at the bottom of the screen, to be burned
			if ( rand() % 4 == 0 )
			{
				PutPixelBuffer( x, 196, 253 );
				PutPixelBuffer( x, 197, 253 );
				PutPixelBuffer( x, 198, 253 );
				PutPixelBuffer( x, 199, 253 );

				PutPixelBuffer( x+1, 196, 253 );
				PutPixelBuffer( x+1, 197, 253 );
				PutPixelBuffer( x+1, 198, 253 );
				PutPixelBuffer( x+1, 199, 253 );

				PutPixelBuffer( x+2, 196, 253 );
				PutPixelBuffer( x+2, 197, 253 );
				PutPixelBuffer( x+2, 198, 253 );
				PutPixelBuffer( x+2, 199, 253 );

				PutPixelBuffer( x+3, 196, 253 );
				PutPixelBuffer( x+3, 197, 253 );
				PutPixelBuffer( x+3, 198, 253 );
				PutPixelBuffer( x+3, 199, 253 );
			}
		}
		// ahhh, now to smooth the fire, we take the average of all
		// the pixels around it
		for ( x = 1; x < 318; x++ )
		{
			for ( int y = 70; y < 199; y++ )
			{
				// since the fire is moving up, the y is decremented by 1
				fire_buffer[(y-1<<8)+(y-1<<6)+x] = ( GetPixelBuffer( x-1, y-1 ) + GetPixelBuffer( x-1, y ) + GetPixelBuffer( x-1, y+1 ) +
																 GetPixelBuffer( x, y-1 ) + GetPixelBuffer( x, y+1 ) +
																 GetPixelBuffer( x+1, y-1 ) + GetPixelBuffer( x+1, y ) + GetPixelBuffer( x+1, y+1 ) ) / 8;
				// if it is not black, fade it one color
				if ( fire_buffer[(y-1<<8)+(y-1<<6)+x] > 0 )
					fire_buffer[(y-1<<8)+(y-1<<6)+x]--;
			}
		}
		// put fire buffer, into our back buffer
		MoveIntoBuffer();
	}
}

void FirePalette()
{
	for ( int a = 0; a < 63; a++ )   // Red
		Pal( a+1, a, 0, 0 );

	for ( a = 0; a < 63; a++ )       // Orange
		Pal( a+64, 63, a/2, 0 );

	for ( a = 0; a < 63; a++ )       // Yellow
		Pal( a+127, 63, (a/2)+31, a );

	for ( a = 0; a < 63; a++ )       // Greenish blue
		Pal( a+190, 63-a, 63-a, 63 );
}
